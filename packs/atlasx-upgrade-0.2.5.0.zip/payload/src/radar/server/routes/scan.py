"""扫描详情页 + 发起扫描页 + 日志页 + 运行中片段（HTMX 轮询）。"""

from __future__ import annotations

from fastapi import APIRouter, Form, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy import select

from radar.collectors.registry import REGISTRY
from radar.server.deps import get_session, view_context
from radar.server.templates_env import templates
from radar.storage.models import ScanRun

router = APIRouter()

_SOURCE_ORDER = [
    "crtsh",
    "subfinder",
    "oneforall",
    "sublist3r",
    "hackertarget",
    "otx",
    "bing",
    "sogou",
    "ksubdomain",
    "fofa",
    "quake",
    "shodan",
    "censys",
    "chaos",
    "hunter",
    "zoomeye",
    "daydaymap",
    "zone0",
    "virustotal",
    "firefly",
    "crawlora_bing",
    "crawlora_google",
    "beian",
    "tianyancha",
    "whoxy",
    "asn",
    "github_dork",
]


def _ordered_sources() -> list[str]:
    """REGISTRY 键按 _SOURCE_ORDER 排序；新增但未列入顺序表的源追加到末尾（动态同步）。"""
    registry_keys = list(REGISTRY.keys())
    ordered = [n for n in _SOURCE_ORDER if n in registry_keys]
    ordered += [n for n in registry_keys if n not in _SOURCE_ORDER]
    return ordered


def _log_lines(run: ScanRun) -> list[dict]:
    """从 scan_run.stats 还原每源成功/失败/超时/熔断的时间线（build-card 的日志页）。"""
    stats = run.stats or {}
    lines: list[dict] = []

    def add(t, level: str, msg: str) -> None:
        # 失败于启动前（started_at 未落库）时回退到 finished_at，避免渲染 --:--:--
        lines.append({"t": t or run.started_at or run.finished_at, "level": level, "msg": msg})

    add(
        run.started_at,
        "info",
        f"扫描启动 · roots={','.join(run.roots or [])} · trigger={run.trigger}",
    )

    # 扫描级失败原因（run_scan_job 捕获异常时写入 stats.error）
    if stats.get("error"):
        add(run.started_at, "error", f"扫描失败：{stats['error']}")
    if stats.get("shutdown") and not stats.get("stopped"):
        add(
            run.finished_at or run.started_at,
            "warn",
            "进程退出/热重载中断 · 新进程将自动续跑（若已启用）",
        )
    elif stats.get("stopped"):
        add(run.finished_at or run.started_at, "warn", "用户停止扫描")

    for name, reason in (stats.get("skipped") or {}).items():
        add(run.started_at, "warn", f"{name}: 未启用（{reason}）")

    for root, fp in (stats.get("wildcard") or {}).items():
        if not isinstance(fp, dict):
            continue
        if fp.get("confirmed"):
            add(
                run.started_at,
                "warn",
                f"泛解析确认 {root} · {len(fp.get('ips', []))} 个探针 IP，子域将折叠",
            )
        elif fp.get("error"):
            add(run.started_at, "warn", f"泛解析检测失败 {root}：{fp['error']}")
        elif fp.get("skipped"):
            add(run.started_at, "warn", f"泛解析检测跳过 {root}（{fp['skipped']}）")
        else:
            add(run.started_at, "info", f"泛解析检测 {root}: 非泛解析")

    _STATUS_WORD = {
        "ok": "✓ 完成",
        "error": "✕ 失败",
        "skipped": "– 跳过（degraded）",
        "breaker": "⛔ 熔断（连败 ≥3）",
    }
    for name in _ordered_sources():
        st = stats.get(name)
        if not isinstance(st, dict):
            continue
        msg = f"{name}: {_STATUS_WORD.get(st.get('status'), st.get('status'))} · 发现 {st.get('found', 0)}"
        if st.get("error"):
            msg += f" · {st['error']}"
        add(run.started_at, "info" if st.get("status") == "ok" else "warn", msg)

    if (stats.get("_capacity") or {}).get("warn"):
        add(run.started_at, "warn", stats["_capacity"]["warn"])
    enrich = stats.get("enrich") or {}
    if isinstance(enrich, dict) and enrich.get("error"):
        add(run.finished_at, "warn", f"enrich 失败：{enrich['error']}")

    agents = stats.get("agents") if isinstance(stats.get("agents"), dict) else {}
    for line in agents.get("thinking") or []:
        if isinstance(line, dict) and line.get("msg"):
            add(run.finished_at or run.started_at, "info", f"AI · {line['msg']}")
        elif isinstance(line, str) and line.strip():
            add(run.finished_at or run.started_at, "info", f"AI · {line.strip()}")
    if agents and not agents.get("thinking"):
        triage = agents.get("triage") if isinstance(agents.get("triage"), dict) else {}
        if triage:
            add(
                run.finished_at or run.started_at,
                "info",
                f"AI 判定 · 资产 {triage.get('total', 0)} · P0 {triage.get('p0', 0)} · P1 {triage.get('p1', 0)}",
            )

    corr = stats.get("correlation") or {}
    if isinstance(corr, dict) and "pairs" in corr:
        add(run.finished_at, "info", f"关联编排：生成 {corr['pairs']} 条关联边")
    diff = stats.get("diff") or {}
    if isinstance(diff, dict):
        add(
            run.finished_at,
            "warn" if diff.get("gone") else "info",
            f"diff：新增 {diff.get('new', 0)} · 未再出现 {diff.get('gone', 0)}",
        )
    add(
        run.finished_at,
        "info",
        f"扫描结束 · 状态 {run.status} · 共发现 {stats.get('total_found', 0)} 条",
    )
    return lines


def _source_status(s, stats: dict) -> list[dict]:
    """把 scan_run.stats 归一成源行 + 雷达环 blip 坐标（沿环均匀分布）。"""
    import math

    rows = []
    ordered = _ordered_sources()
    n = len(ordered)
    for i, name in enumerate(ordered):
        cls = REGISTRY.get(name)
        st = stats.get(name) or (stats.get("skipped") or {}).get(name)
        angle = (i / n) * 2 * math.pi
        # 归一化 status：st 可能是 dict(已运行) / "skip"(字符串跳过) / None
        if isinstance(st, dict):
            status = st.get("status") or "ok"
            found = st.get("found", 0)
        elif isinstance(st, str):
            status = st
            found = 0
        else:
            status = "skip"
            found = 0
        rows.append(
            {
                "name": name,
                "needs_key": bool(cls and cls.NEEDS_KEY),
                "status": status,
                "found": found,
                "top": round(48 - 42 * math.cos(angle)),
                "left": round(48 + 42 * math.sin(angle)),
            }
        )
    return rows


# 对外展示的 7 段流水线（内部 post 并入 enrich 展示）
_STAGE_DEFS = (
    ("wildcard", "泛解析"),
    ("collect", "采集"),
    ("project", "投影"),
    ("enrich", "富化"),
    ("agent", "AI 判定"),
    ("correlate", "关联"),
    ("deep_dive", "深挖"),
    ("diff", "Diff"),
)

_STAGE_ORDER_IDS = [s[0] for s in _STAGE_DEFS]

_ENRICH_STEP_LABELS = (
    ("ip", "IP 解析"),
    ("alive", "存活探测"),
    ("prober", "主动探测"),
    ("scan_model", "扫描模型"),
    ("veo", "指纹"),
    ("paths", "路径发现"),
    ("path_probe", "路径状态"),
    ("paths_priority", "优先补爬"),
    ("discovery_tags", "发现标注"),
    ("risk_derived", "风险派生"),
    ("risk_enhanced", "风险增强"),
)

_AGENT_STEP_LABELS = (
    ("triage", "分级"),
    ("ownership", "归属"),
    ("prescreen", "预筛"),
)


def _stage_index(stage: str) -> int:
    """当前 stats.stage → 展示段下标；done/post 特殊处理。

    空 stage → -1（未知，勿当成全部完成）。
    """
    if stage == "done":
        return len(_STAGE_ORDER_IDS)  # 全部完成
    if not stage:
        return -1
    if stage == "post":
        return _STAGE_ORDER_IDS.index("enrich")
    if stage in _STAGE_ORDER_IDS:
        return _STAGE_ORDER_IDS.index(stage)
    return -1


def _block_status(block) -> str:
    """单块 stats → done/error/pending/running。"""
    if block is None:
        return "pending"
    if isinstance(block, dict):
        if block.get("error"):
            return "error"
        if block.get("skipped"):
            return "skipped"
        if block.get("status") == "running":
            return "running"
        return "done"
    return "done"


def _step_detail(block) -> str:
    if not isinstance(block, dict):
        return ""
    if block.get("error"):
        return str(block["error"])[:80]
    if block.get("skipped"):
        return str(block["skipped"])
    parts: list[str] = []
    for k in (
        "probed",
        "alive",
        "dead",
        "resolved",
        "cdn",
        "applied",
        "open",
        "with_paths",
        "candidates",
        "remaining",
        "pairs",
        "judged",
        "screened",
        "total",
        "p0",
        "p1",
    ):
        if k in block and not isinstance(block[k], (dict, list)):
            parts.append(f"{k} {block[k]}")
    prog = _progress_fields(block)
    if prog.get("text"):
        parts.append(prog["text"])
    if block.get("incomplete"):
        parts.append("未完成")
    if block.get("ok") is True and not parts:
        return "ok"
    return " · ".join(parts[:4])


def _progress_fields(block) -> dict:
    """从 stats 块提取 {done,total,pct,text}；无进度返回空 dict。"""
    if not isinstance(block, dict):
        return {}
    prog = block.get("progress")
    if not isinstance(prog, dict):
        return {}
    total = prog.get("total")
    if not total:
        return {}
    try:
        done = int(prog.get("done") or 0)
        total_i = int(total)
    except (TypeError, ValueError):
        return {}
    if total_i <= 0:
        return {}
    pct = int(100 * done / total_i)
    return {
        "done": done,
        "total": total_i,
        "pct": pct,
        "text": f"{done}/{total_i} ({pct}%)",
    }


def _item(
    name: str,
    status: str,
    *,
    detail: str = "",
    block: dict | None = None,
    done: int | None = None,
    total: int | None = None,
) -> dict:
    """统一步骤行：name + status + detail + 可选进度。"""
    prog = _progress_fields(block) if block else {}
    if done is not None and total is not None and total > 0 and not prog:
        pct = int(100 * done / total)
        prog = {
            "done": done,
            "total": total,
            "pct": pct,
            "text": f"{done}/{total} ({pct}%)",
        }
    row = {
        "name": name,
        "status": status,
        "detail": detail,
        "done": prog.get("done"),
        "total": prog.get("total"),
        "pct": prog.get("pct"),
        "progress": prog.get("text") or "",
    }
    return row


def _stage_progress(items: list[dict]) -> dict:
    """阶段级进度：已终结步骤 / 总步骤。"""
    if not items:
        return {}
    terminal = {"ok", "done", "error", "skip", "skipped", "breaker"}
    done_n = sum(1 for it in items if it.get("status") in terminal)
    total = len(items)
    pct = int(100 * done_n / total) if total else 0
    return {
        "done": done_n,
        "total": total,
        "pct": pct,
        "text": f"{done_n}/{total} ({pct}%)",
    }


def _collect_aggregate(stats: dict, prog_sources: dict | None) -> tuple[str, str, int, int, int]:
    """采集聚合：(status, summary, ok_n, err_n, total_found)。不列源名。"""
    ordered = _ordered_sources()
    ok_n = err_n = run_n = skip_n = 0
    found = 0
    for name in ordered:
        st = None
        if prog_sources and isinstance(prog_sources.get(name), dict):
            st = prog_sources[name]
        elif isinstance(stats.get(name), dict):
            st = stats[name]
        elif name in (stats.get("skipped") or {}):
            skip_n += 1
            continue
        else:
            continue
        status = st.get("status") or "ok"
        if status == "ok":
            ok_n += 1
        elif status == "error":
            err_n += 1
        elif status == "running":
            run_n += 1
        else:
            skip_n += 1
        found += int(st.get("found") or 0)
    if stats.get("total_found"):
        found = int(stats["total_found"])
    total_sources = ok_n + err_n + run_n + skip_n
    if run_n:
        status = "running"
    elif err_n and ok_n == 0 and total_sources:
        status = "error"
    elif total_sources:
        status = "done"
    else:
        status = "pending"
    if total_sources:
        pct = int(100 * (ok_n + err_n + skip_n) / total_sources)
        summary = f"{ok_n + err_n + skip_n}/{total_sources} ({pct}%) · 发现 {found}"
        if err_n:
            summary += f" · 失败 {err_n}"
    elif found:
        summary = f"发现 {found}"
    else:
        summary = "等待采集"
    return status, summary, ok_n, err_n, found


def _collect_source_items(
    stats: dict,
    prog_sources: dict | None,
    *,
    done: bool,
    show_pending: bool,
) -> list[dict]:
    """采集阶段每源一行；含根域 progress（如 github 1/3 (33%)）。"""
    items: list[dict] = []
    ordered = _ordered_sources()
    for name in ordered:
        st = None
        if prog_sources and isinstance(prog_sources.get(name), dict):
            st = prog_sources[name]
        elif isinstance(stats.get(name), dict):
            st = stats[name]
        elif name in (stats.get("skipped") or {}):
            if done or show_pending:
                items.append(
                    _item(
                        name,
                        "skip",
                        detail=str((stats.get("skipped") or {}).get(name) or "跳过"),
                    )
                )
            continue
        elif show_pending:
            items.append(_item(name, "pending", detail=""))
            continue
        else:
            continue
        status = st.get("status") or "ok"
        found_n = int(st.get("found") or 0)
        detail = f"发现 {found_n}"
        if st.get("error"):
            detail = str(st["error"])[:80]
        if not done and not show_pending and status not in ("running", "ok", "error"):
            continue
        items.append(_item(name, status, detail=detail, block=st))
    if not done and any(i["status"] == "running" for i in items):
        items.sort(
            key=lambda x: 0
            if x["status"] == "running"
            else (1 if x["status"] == "error" else (2 if x["status"] in ("ok", "done") else 3))
        )
    return items


def _pipeline_view(
    stats: dict,
    stage: str,
    done: bool,
    prog_sources: dict | None = None,
) -> tuple[list[dict], dict]:
    """扫描详情主视图：7 段流水线状态 + KPI。

    返回 (stages, kpi)；stages 每项含 id/label/status/summary/steps/log_hint。
    """
    stats = stats or {}
    stage = stage or stats.get("stage") or ""
    # 终态用真实停点：stage=done 才算跑完；cancelled/failed 停在中间段 → 后续 skipped
    if done:
        cur_idx = (
            len(_STAGE_ORDER_IDS)
            if stage in ("", "done")
            else _stage_index(stage)
        )
    else:
        cur_idx = _stage_index(stage)
    # 仅 collect 阶段合并 KV 实时进度；过后段残留 running 会污染摘要
    if stage not in ("collect", "") and prog_sources:
        prog_sources = None
    stages: list[dict] = []

    def _phase_status(idx: int, has_data: bool, data_status: str) -> str:
        if done:
            if data_status == "error":
                return "error"
            if cur_idx >= len(_STAGE_ORDER_IDS):
                # 完整跑完
                return data_status if data_status != "pending" else "done"
            # 中途结束：已过段 done，当前段保留 data，未到段 skipped
            if idx < cur_idx:
                return data_status if data_status != "pending" else "done"
            if idx == cur_idx:
                return data_status if data_status != "pending" else "done"
            return "skipped"
        if cur_idx < 0:
            # 未知阶段：有数据标 done，否则 pending
            return data_status if has_data else "pending"
        if idx < cur_idx:
            return data_status if data_status != "pending" else "done"
        if idx == cur_idx:
            return "running" if data_status != "error" else "error"
        return "pending"

    # --- wildcard ---
    wc = stats.get("wildcard") if isinstance(stats.get("wildcard"), dict) else {}
    confirmed = sum(1 for v in wc.values() if isinstance(v, dict) and v.get("confirmed"))
    w_err = sum(1 for v in wc.values() if isinstance(v, dict) and v.get("error"))
    w_skip = sum(1 for v in wc.values() if isinstance(v, dict) and v.get("skipped"))
    w_ok = sum(
        1
        for v in wc.values()
        if isinstance(v, dict) and not v.get("error") and not v.get("skipped") and not v.get("confirmed")
    )
    w_items: list[dict] = []
    for root, fp in wc.items():
        if not isinstance(fp, dict):
            continue
        if fp.get("confirmed"):
            w_items.append(
                _item(root, "ok", detail=f"确认泛解析 · {len(fp.get('ips') or [])} IP")
            )
        elif fp.get("error"):
            w_items.append(_item(root, "error", detail=str(fp["error"])[:80]))
        elif fp.get("skipped"):
            w_items.append(_item(root, "skip", detail=str(fp["skipped"])))
        else:
            w_items.append(_item(root, "ok", detail="非泛解析"))
    if wc:
        w_summary = f"根域 {len(wc)}"
        bits = []
        if confirmed:
            bits.append(f"泛解析 {confirmed}")
        if w_ok:
            bits.append(f"正常 {w_ok}")
        if w_skip:
            bits.append(f"跳过 {w_skip}")
        if w_err:
            bits.append(f"失败 {w_err}")
        if bits:
            w_summary += " · " + " · ".join(bits)
        w_data = "error" if w_err and not (confirmed or w_ok) else "done"
    else:
        w_summary = "—"
        w_data = "pending"
    w_phase = _phase_status(0, bool(wc), w_data)
    w_prog = _stage_progress(w_items)
    stages.append(
        {
            "id": "wildcard",
            "label": "泛解析",
            "status": w_phase,
            "summary": w_summary,
            "steps": [],
            "step_items": w_items,
            "progress": w_prog.get("text") or "",
            "pct": w_prog.get("pct"),
            "log_hint": False,
        }
    )

    # --- collect ---
    c_status, c_summary, _ok, err_n, found = _collect_aggregate(stats, prog_sources)
    c_phase = _phase_status(1, c_status != "pending", c_status)
    c_items = _collect_source_items(
        stats,
        prog_sources,
        done=done,
        show_pending=(not done and c_phase == "running"),
    )
    c_prog = _stage_progress(c_items) if c_items else {}
    if c_prog.get("text") and c_status != "pending":
        # 摘要优先用阶段步进进度
        c_summary = c_prog["text"] + (
            f" · 发现 {found}" if found else ""
        ) + (f" · 失败 {err_n}" if err_n else "")
    stages.append(
        {
            "id": "collect",
            "label": "采集",
            "status": c_phase,
            "summary": c_summary,
            "steps": [],
            "step_items": c_items,
            "progress": c_prog.get("text") or "",
            "pct": c_prog.get("pct"),
            "log_hint": err_n > 0,
            "err_n": err_n,
        }
    )

    # --- project ---
    proj = stats.get("project")
    p_data = _block_status(proj)
    p_items: list[dict] = []
    if isinstance(proj, dict) and proj.get("ok"):
        p_summary = "投影完成"
        p_items.append(_item("投影", "ok", detail="RawFinding → Asset"))
    elif isinstance(proj, dict) and proj.get("error"):
        p_summary = str(proj["error"])[:100]
        p_items.append(_item("投影", "error", detail=str(proj["error"])[:80]))
    else:
        p_summary = "—"
        if not done and cur_idx == 2:
            p_items.append(_item("投影", "running", detail="写入资产表…"))
    p_phase = _phase_status(2, proj is not None, p_data)
    p_prog = _stage_progress(p_items)
    stages.append(
        {
            "id": "project",
            "label": "投影",
            "status": p_phase,
            "summary": p_summary,
            "steps": [],
            "step_items": p_items,
            "progress": p_prog.get("text") or "",
            "pct": p_prog.get("pct"),
            "log_hint": False,
        }
    )

    # --- enrich (+ post 子步并入) ---
    enrich = stats.get("enrich") if isinstance(stats.get("enrich"), dict) else {}
    # paths 中途写 enrich.paths_progress；合成到 paths 块供步骤行读进度
    pp = enrich.get("paths_progress")
    if (
        isinstance(pp, dict)
        and pp.get("total")
        and (
            enrich.get("paths") is None
            or (
                isinstance(enrich.get("paths"), dict)
                and enrich["paths"].get("status") == "running"
            )
        )
    ):
        enrich = dict(enrich)
        enrich["paths"] = {
            "status": "running",
            "incomplete": True,
            "progress": {
                "done": int(pp.get("done") or 0),
                "total": int(pp.get("total") or 0),
            },
            "current": pp.get("current") or "",
            "remaining": pp.get("remaining"),
        }
    e_steps = []
    e_items: list[dict] = []
    for sid, label in _ENRICH_STEP_LABELS:
        block = enrich.get(sid)
        if block is None:
            st = "pending"
            detail = ""
            it = _item(label, "pending")
        else:
            st = _block_status(block if not isinstance(block, (int, float)) else {"ok": True})
            if isinstance(block, (int, float)):
                detail = str(block)
                st = "done"
                it = _item(label, "done", detail=detail)
            else:
                detail = _step_detail(block)
                if st == "running" and not detail:
                    cur = block.get("current")
                    detail = str(cur)[:60] if cur else "进行中"
                # 本轮未耗尽（如 paths incomplete）且扫描仍在富化 → 视为进行中
                if (
                    not done
                    and cur_idx == 3
                    and st == "done"
                    and block.get("incomplete")
                    and _progress_fields(block)
                ):
                    st = "running"
                it = _item(label, st, detail=detail, block=block if isinstance(block, dict) else None)
        e_steps.append({"id": sid, "label": label, "status": st, "detail": detail})
        e_items.append(it)
    # 只展示已出现或当前阶段相关的子步，避免一长串 pending
    if enrich or (not done and cur_idx == 3):
        if not done and cur_idx == 3:
            main_ids = {"ip", "alive", "prober", "scan_model", "veo", "paths", "path_probe"}
            visible_steps = [
                s
                for s in e_steps
                if s["status"] != "pending" or s["id"] in main_ids
            ]
            visible_items = [
                it
                for it, s in zip(e_items, e_steps, strict=True)
                if s["status"] != "pending" or s["id"] in main_ids
            ]
        else:
            visible_steps = [s for s in e_steps if s["status"] != "pending"]
            visible_items = [it for it in e_items if it["status"] != "pending"]
    else:
        visible_steps = []
        visible_items = []
    e_has = bool(enrich)
    e_data = "error" if any(s["status"] == "error" for s in visible_steps) else (
        "done" if e_has else "pending"
    )
    # 摘要
    e_bits = []
    alive = enrich.get("alive") if isinstance(enrich.get("alive"), dict) else {}
    if alive:
        e_bits.append(f"存活 {alive.get('alive', 0)}")
    paths = enrich.get("paths") if isinstance(enrich.get("paths"), dict) else {}
    if paths:
        e_bits.append(f"路径 {paths.get('with_paths', 0)}")
        if paths.get("incomplete"):
            e_bits.append("路径未完成")
    e_phase = _phase_status(3, e_has, e_data)
    e_prog = _stage_progress(visible_items)
    e_summary = e_prog.get("text") or (
        " · ".join(e_bits) if e_bits else ("进行中" if (not done and cur_idx == 3) else "—")
    )
    if e_prog.get("text") and e_bits:
        e_summary = e_prog["text"] + " · " + " · ".join(e_bits)
    stages.append(
        {
            "id": "enrich",
            "label": "富化",
            "status": e_phase,
            "summary": e_summary,
            "steps": visible_steps,
            "step_items": visible_items,
            "progress": e_prog.get("text") or "",
            "pct": e_prog.get("pct"),
            "log_hint": False,
        }
    )

    # --- agent ---
    agents = stats.get("agents") if isinstance(stats.get("agents"), dict) else {}
    a_steps = []
    a_items: list[dict] = []
    for sid, label in _AGENT_STEP_LABELS:
        block = agents.get(sid)
        if block is None:
            if not done and cur_idx == 4:
                a_items.append(_item(label, "pending"))
            continue
        st = _block_status(block)
        detail = _step_detail(block)
        a_steps.append(
            {
                "id": sid,
                "label": label,
                "status": st,
                "detail": detail,
            }
        )
        a_items.append(_item(label, st, detail=detail, block=block if isinstance(block, dict) else None))
    a_has = bool(agents)
    a_data = "error" if any(s["status"] == "error" for s in a_steps) else (
        "done" if a_has else "pending"
    )
    triage = agents.get("triage") if isinstance(agents.get("triage"), dict) else {}
    a_prog = _stage_progress(a_items)
    thinking = []
    for line in agents.get("thinking") or []:
        if isinstance(line, dict) and line.get("msg"):
            thinking.append(line)
        elif isinstance(line, str) and line.strip():
            thinking.append({"msg": line.strip()})
    if triage:
        a_summary = f"资产 {triage.get('total', 0)} · P0 {triage.get('p0', 0)} · P1 {triage.get('p1', 0)}"
        if a_prog.get("text"):
            a_summary = a_prog["text"] + " · " + a_summary
    elif a_has:
        a_summary = a_prog.get("text") or "已判定"
    else:
        a_summary = "—"
    stages.append(
        {
            "id": "agent",
            "label": "AI 判定",
            "status": _phase_status(4, a_has, a_data),
            "summary": a_summary,
            "steps": a_steps,
            "step_items": a_items,
            "progress": a_prog.get("text") or "",
            "pct": a_prog.get("pct"),
            "thinking": thinking[-40:],
            "log_hint": bool(thinking),
        }
    )

    # --- correlate (+ burp_triage) ---
    corr = stats.get("correlation")
    burp = stats.get("burp_triage")
    c_steps = []
    corr_items: list[dict] = []
    if isinstance(corr, dict):
        detail = _step_detail(corr) or (f"pairs {corr.get('pairs')}" if "pairs" in corr else "")
        c_steps.append(
            {
                "id": "correlation",
                "label": "关联边",
                "status": _block_status(corr),
                "detail": detail,
            }
        )
        corr_items.append(_item("关联边", _block_status(corr), detail=detail, block=corr))
    if isinstance(burp, dict):
        detail = _step_detail(burp)
        c_steps.append(
            {
                "id": "burp_triage",
                "label": "Yakit 分桶",
                "status": _block_status(burp),
                "detail": detail,
            }
        )
        corr_items.append(_item("Yakit 分桶", _block_status(burp), detail=detail, block=burp))
    if not corr_items and not done and cur_idx == 5:
        corr_items.append(_item("关联边", "running", detail="生成关联…"))
    corr_has = corr is not None or burp is not None
    corr_data = "error" if any(s["status"] == "error" for s in c_steps) else (
        "done" if corr_has else "pending"
    )
    corr_prog = _stage_progress(corr_items)
    if isinstance(corr, dict) and "pairs" in corr:
        corr_summary = f"关联 {corr.get('pairs', 0)} 条"
        if corr_prog.get("text"):
            corr_summary = corr_prog["text"] + " · " + corr_summary
    elif corr_has:
        corr_summary = corr_prog.get("text") or "已完成"
    else:
        corr_summary = "—"
    stages.append(
        {
            "id": "correlate",
            "label": "关联",
            "status": _phase_status(5, corr_has, corr_data),
            "summary": corr_summary,
            "steps": c_steps,
            "step_items": corr_items,
            "progress": corr_prog.get("text") or "",
            "pct": corr_prog.get("pct"),
            "log_hint": False,
        }
    )

    # --- deep_dive ---
    dd = stats.get("deep_dive") if isinstance(stats.get("deep_dive"), dict) else None
    dd_items: list[dict] = []
    if dd is not None:
        if dd.get("skipped"):
            reason = str(dd.get("reason") or "disabled")
            dd_summary = "已暂停" if reason == "paused" else f"跳过 · {reason}"
            dd_data = "skipped"
            dd_items.append(_item("深挖", "skip", detail=dd_summary))
        elif dd.get("status") in ("pending", "running"):
            dd_summary = "主扫描完成 · 深挖进行中"
            dd_data = "running"
            dd_items.append(_item("深挖", "running", detail="tonight 作业单…"))
        else:
            done_n_dd = int(dd.get("done") or 0)
            partial_n = int(dd.get("partial") or 0)
            sel_n = len(dd.get("selected") or [])
            dd_summary = f"完成 {done_n_dd}/{sel_n or dd.get('cap', 8)}"
            if partial_n:
                dd_summary += f" · 部分 {partial_n}"
            if dd.get("skipped_favicon"):
                dd_summary += f" · 同指纹跳过 {dd['skipped_favicon']}"
            dd_items.append(
                _item(
                    "作业单",
                    "error" if dd.get("error") else "ok",
                    detail=dd_summary,
                    block=dd,
                )
            )
            dd_data = "error" if dd.get("error") else "done"
            if dd.get("incomplete"):
                dd_data = "error"
    else:
        dd_summary = "—"
        dd_data = "pending"
        if not done and cur_idx == 6:
            dd_items.append(_item("深挖", "running", detail="tonight 作业单…"))
    dd_prog = _stage_progress(dd_items)
    stages.append(
        {
            "id": "deep_dive",
            "label": "深挖",
            "status": _phase_status(6, dd is not None, dd_data),
            "summary": dd_summary,
            "steps": [],
            "step_items": dd_items,
            "progress": dd_prog.get("text") or "",
            "pct": dd_prog.get("pct"),
            "log_hint": False,
        }
    )

    # --- diff ---
    diff = stats.get("diff") if isinstance(stats.get("diff"), dict) else None
    d_items: list[dict] = []
    if diff is not None:
        if diff.get("baseline"):
            d_summary = f"基线 {diff.get('baseline_count', diff.get('landed', 0))}"
            d_items.append(
                _item(
                    "基线",
                    "ok",
                    detail=f"{diff.get('baseline_count', diff.get('landed', 0))} 条入库",
                )
            )
        else:
            d_summary = f"新增 {diff.get('new', 0)} · 消失 {diff.get('gone', 0)}"
            if diff.get("lost"):
                d_summary += f"（确认 {diff.get('lost')}）"
            if diff.get("gone_suppressed_alive"):
                d_summary += f" · 复核仍活 {diff.get('gone_suppressed_alive')}"
            if diff.get("skipped_gone_incomplete"):
                d_summary += " · 消失已跳过"
            d_items.append(_item("新增", "ok", detail=str(diff.get("new", 0))))
            d_items.append(_item("消失", "ok", detail=str(diff.get("gone", 0))))
        d_data = "done"
    else:
        d_summary = "—"
        d_data = "pending"
        if not done and cur_idx == 7:
            d_items.append(_item("Diff", "running", detail="对比上轮落地…"))
    d_prog = _stage_progress(d_items)
    stages.append(
        {
            "id": "diff",
            "label": "Diff",
            "status": _phase_status(7, diff is not None, d_data),
            "summary": d_summary,
            "steps": [],
            "step_items": d_items,
            "progress": d_prog.get("text") or "",
            "pct": d_prog.get("pct"),
            "log_hint": False,
        }
    )

    done_n = sum(1 for s in stages if s["status"] in ("done", "error"))
    running = next((s for s in stages if s["status"] == "running"), None)
    fully_done = done and cur_idx >= len(_STAGE_ORDER_IDS)
    if running:
        current_label, current_id = running["label"], running["id"]
    elif fully_done:
        current_label, current_id = "已完成", "done"
    elif done and 0 <= cur_idx < len(stages):
        current_label, current_id = stages[cur_idx]["label"], stages[cur_idx]["id"]
    else:
        current_label, current_id = ("—", "")
    kpi = {
        "total_found": found if found else int(stats.get("total_found") or 0),
        "done_stages": done_n,
        "total_stages": len(stages),
        "current_label": current_label,
        "current_id": current_id,
        "pct": int(100 * done_n / len(stages)) if stages else 0,
    }

    # 焦点面板：只展开「当前阶段」在做什么（渐进披露，非全量时间线）
    focus_id = current_id if current_id and current_id != "done" else (
        stages[cur_idx]["id"] if done and 0 <= cur_idx < len(stages) else (stages[-1]["id"] if fully_done else "")
    )
    if fully_done:
        focus_id = "diff" if any(s["id"] == "diff" and s["status"] == "done" for s in stages) else (
            next((s["id"] for s in reversed(stages) if s["status"] == "done"), "diff")
        )
    focus_stage = next((s for s in stages if s["id"] == focus_id), None)
    focus = _build_focus(stats, focus_stage, prog_sources if stage in ("collect", "") else None, done=done)
    kpi["focus"] = focus
    return stages, kpi


def _build_focus(
    _stats: dict,
    focus_stage: dict | None,
    _prog_sources: dict | None,
    *,
    done: bool,
) -> dict:
    """当前阶段活动明细：优先复用 stage.step_items（含进度文案）。"""
    if focus_stage is None:
        return {
            "id": "",
            "label": "等待开始",
            "headline": "流水线尚未启动",
            "summary": "",
            "items": [],
            "log_hint": False,
        }
    sid = focus_stage["id"]
    label = focus_stage["label"]
    summary = focus_stage.get("summary") or ""
    headline = {
        "wildcard": "正在检测泛解析",
        "collect": "正在采集资产",
        "project": "正在投影入库",
        "enrich": "正在富化资产",
        "agent": "正在做 AI 判定",
        "correlate": "正在关联与分桶",
        "deep_dive": "正在深挖 tonight",
        "diff": "正在计算变更",
    }.get(sid, label)
    if done and focus_stage.get("status") in ("done", "error", "skipped"):
        headline = {
            "wildcard": "泛解析结果",
            "collect": "采集结果",
            "project": "投影结果",
            "enrich": "富化结果",
            "agent": "判定结果",
            "correlate": "关联结果",
            "deep_dive": "深挖结果",
            "diff": "变更结果",
        }.get(sid, label)

    items = list(focus_stage.get("step_items") or [])
    # 富化刚进入、子步尚未落库时给主步占位
    if sid == "enrich" and not items and not done:
        for _eid, elabel in _ENRICH_STEP_LABELS[:7]:
            items.append(_item(elabel, "pending"))

    return {
        "id": sid,
        "label": label,
        "headline": headline,
        "summary": summary,
        "items": items,
        "progress": focus_stage.get("progress") or "",
        "pct": focus_stage.get("pct"),
        "log_hint": bool(focus_stage.get("log_hint")),
        "status": focus_stage.get("status") or "pending",
    }


@router.get("/scan-new", response_class=HTMLResponse)
def scan_new(request: Request, project_id: int | None = None):
    from radar.storage.models import Enterprise, Project

    with get_session() as s:
        # 全源自动启用（没 key/报错自动跳过），页面只展示源状态速览
        kinds = {
            name: {"needs_key": bool(cls.NEEDS_KEY), "source_type": cls.SOURCE_TYPE}
            for name, cls in sorted(REGISTRY.items())
        }
        projects = (
            s.execute(select(Project).order_by(Project.name)).scalars().all()
        )
        enterprises = (
            s.execute(select(Enterprise).order_by(Enterprise.name)).scalars().all()
        )
        ent_by_id = {e.id: e.name for e in enterprises}
        project_rows = [
            {
                "id": p.id,
                "name": p.name,
                "enterprise_name": ent_by_id.get(p.enterprise_id) or "",
            }
            for p in projects
        ]
        selected = None
        prefill_roots = ""
        if project_id is not None:
            p = s.get(Project, project_id)
            if p is not None:
                selected = {
                    "id": p.id,
                    "name": p.name,
                    "enterprise_name": ent_by_id.get(p.enterprise_id) or "",
                }
                prefill_roots = "\n".join(p.scope_roots or [])
        return templates.TemplateResponse(
            request,
            "scan_new.html",
            {
                "request": request,
                "kinds": kinds,
                "projects": project_rows,
                "enterprises": enterprises,
                "selected_project": selected,
                "prefill_roots": prefill_roots,
                **view_context(s),
            },
        )


@router.get("/scan/new")
def scan_new_alias():
    """施工卡路径别名，指向实现路由。"""
    return RedirectResponse("/scan-new", status_code=307)


@router.get("/scans", response_class=HTMLResponse)
def scans_list(request: Request):
    """扫描历史列表：按项目分组展示，每组含该项目的全部任务。

    未挂项目（project_id 为空）的扫描归入「未分组」组。
    """
    from radar.storage.models import Project

    with get_session() as s:
        runs = s.execute(select(ScanRun).order_by(ScanRun.id.desc()).limit(200)).scalars().all()
        projects = {
            p.id: p.name
            for p in s.execute(select(Project)).scalars().all()
        }
        groups: dict[int | None, list[ScanRun]] = {}
        for r in runs:
            groups.setdefault(r.project_id, []).append(r)

        # 按项目汇总资产数（每组的根域集合 → 该根域下的资产总数）
        project_list: list[dict] = []
        for pid, gruns in groups.items():
            name = projects.get(pid) if pid is not None else None
            roots: list[str] = []
            for r in gruns:
                roots.extend(r.roots or [])
            assets = _assets_under_roots(s, roots)
            project_list.append(
                {
                    "id": pid,
                    "name": name or "未分组",
                    "unnamed": name is None,
                    "runs": gruns,
                    "asset_count": len(assets),
                    "root_count": len(set(roots)),
                    "total_found": sum((r.stats or {}).get("total_found", 0) for r in gruns),
                }
            )
        return templates.TemplateResponse(
            request,
            "scans.html",
            {"request": request, "projects": project_list, **view_context(s)},
        )


def _assets_under_roots(s, roots: list[str]):
    """返回属于这些根域的全部资产（root_domain 本身 + 其下 subdomain）。"""
    from sqlalchemy import or_

    from radar.storage.models import Asset

    conds = [Asset.identity.in_(roots)]
    for r in roots:
        conds.append(Asset.identity.like("%." + r))
    return s.execute(select(Asset).where(or_(*conds))).scalars().all()


def _roots_still_referenced(
    s, roots: list[str], *, exclude_project_id: int | None = None
) -> set[str]:
    """仍存在的 ScanRun 仍引用的根域（删资产时须保留）。

    项目 scope 只是扫描配置，不构成数据占用；独占判定只看还在的任务。
    """
    roots_set = {r for r in (roots or []) if r}
    if not roots_set:
        return set()
    held: set[str] = set()
    for run in s.execute(select(ScanRun)).scalars().all():
        if exclude_project_id is not None and run.project_id == exclude_project_id:
            continue
        for r in run.roots or []:
            if r in roots_set:
                held.add(r)
    return held


def _delete_assets_exclusive(
    s, roots: list[str], *, exclude_project_id: int | None = None
) -> int:
    """只删未被其它仍在 ScanRun 引用的根域资产。"""
    held = _roots_still_referenced(s, roots, exclude_project_id=exclude_project_id)
    exclusive = [r for r in roots if r and r not in held]
    return _delete_assets(s, exclusive, force=True)


def _delete_assets(s, roots: list[str], *, force: bool = False) -> int:
    """按根域级联删除资产：PathFound / Correlation 边 / 引用这些 identity 的 ChangeEvent。

    默认：若仍有 RootMapping 登记该根域则跳过（避免删企业映射前误伤，或跨企业共享根域）。
    force=True：忽略映射（删除扫描任务/项目时用——UI 承诺「资产一并删除」）。

    Correlation 为派生表（下次 correlate 会 TRUNCATE 重建）：清边用 SAVEPOINT 尽力而为，
    被并发扫描锁住时跳过，绝不让整次删任务 500（曾 LockNotAvailable @ lock_timeout=15s）。
    """
    import logging

    from sqlalchemy import delete, text
    from sqlalchemy.exc import OperationalError

    from radar.storage.models import Asset, ChangeEvent, Correlation, PathFound, RootMapping

    log = logging.getLogger(__name__)
    roots = list({r for r in (roots or []) if r})
    if not roots:
        return 0
    if not force:
        still_mapped = {
            r
            for (r,) in s.execute(
                select(RootMapping.root_domain).where(RootMapping.root_domain.in_(roots))
            ).all()
        }
        roots = [r for r in roots if r not in still_mapped]
        if not roots:
            return 0

    assets = _assets_under_roots(s, roots)
    ids = [a.identity for a in assets if a.identity]
    if not ids:
        return 0

    # 删资产路径抬高超时：大根域上千 identity + 并发 enrich 写库时默认 15s 锁超时必炸
    try:
        s.execute(text("SET LOCAL lock_timeout = '120s'"))
        s.execute(text("SET LOCAL statement_timeout = '180s'"))
    except Exception:  # noqa: BLE001, S110
        pass

    chunk = 500
    for i in range(0, len(ids), chunk):
        part = ids[i : i + chunk]
        s.execute(delete(PathFound).where(PathFound.asset_identity.in_(part)))
        s.execute(delete(ChangeEvent).where(ChangeEvent.identity.in_(part)))

    # 派生边：SAVEPOINT 隔离，锁冲突不回滚已删的 PathFound/ChangeEvent
    for i in range(0, len(ids), chunk):
        part = ids[i : i + chunk]
        nested = s.begin_nested()
        try:
            s.execute(
                delete(Correlation).where(
                    (Correlation.a_identity.in_(part)) | (Correlation.b_identity.in_(part))
                )
            )
            nested.commit()
        except OperationalError as exc:
            nested.rollback()
            log.warning(
                "correlation cleanup skipped (lock/timeout; next correlate rebuilds): %r",
                exc,
            )
            break  # 后续 chunk 多半同样抢不到锁
        except Exception as exc:  # noqa: BLE001
            nested.rollback()
            log.warning("correlation cleanup skipped: %r", exc)
            break

    # 批量删 Asset（避免逐行 ORM delete）
    for i in range(0, len(ids), chunk):
        part = ids[i : i + chunk]
        s.execute(delete(Asset).where(Asset.identity.in_(part)))
    return len(ids)


def _delete_query_log(s, roots: list[str]) -> int:
    """按根域列表删 QueryLog（这些根域的查询审计/配额记录）。

    QueryLog 无 run_id 关联（按 root 记），删企业/项目时连带清掉这些根域的全部查询日志，
    避免删了根域/资产后还留着一堆指向"不存在根域"的日志。
    """
    if not roots:
        return 0
    from sqlalchemy import delete

    from radar.storage.models import QueryLog

    return s.execute(delete(QueryLog).where(QueryLog.root.in_(roots))).rowcount or 0


def _delete_blocked(run: ScanRun) -> bool:
    """True = 禁止删除。仅拦进行中（created/running）。

    cancelled 立刻可删：删除时保留 cancel 标，worker 看到后停写，避免等收尾。
    """
    return run.status in ("created", "running")


def _delete_run_kv(s, run_id: int) -> None:
    """清掉挂在该任务上的 KvState（进度 / 路径进度；cancel 由调用方决定去留）。"""
    from radar.storage.models import KvState

    for key in (f"scan_progress:{run_id}", f"paths_progress:{run_id}"):
        row = s.get(KvState, key)
        if row is not None:
            s.delete(row)


def _delete_run(s, run_id: int) -> list[str]:
    """删除单个扫描任务：释放锁 + 删 change_event/raw_finding/进度 KV/run。

    保留/写入 cancel 标：worker 收尾看到后停写，避免删 run 后 FK 炸。
    返回该 run 的 roots（供调用方决定是否连带删资产）。
    """
    from sqlalchemy import delete

    from radar.storage.db import kv_set
    from radar.storage.models import ChangeEvent, KvState, RawFinding

    lock = s.get(KvState, "running_scan_id")
    if lock is not None and isinstance(lock.value, dict) and lock.value.get("id") == run_id:
        s.delete(lock)
    run = s.get(ScanRun, run_id)
    roots = list(run.roots or []) if run is not None else []
    # 收尾中的 cancelled：留 cancel 标让 worker 停写。终态无 worker，清掉残留。
    if run is not None and run.status == "cancelled" and run.finished_at is None:
        kv_set(s, f"cancel_scan:{run_id}", {"cancelled": True, "deleted": True})
    else:
        cancel_row = s.get(KvState, f"cancel_scan:{run_id}")
        if cancel_row is not None:
            s.delete(cancel_row)
    _delete_run_kv(s, run_id)
    s.execute(delete(ChangeEvent).where(ChangeEvent.scan_run_id == run_id))
    s.execute(delete(RawFinding).where(RawFinding.scan_run_id == run_id))
    if run is not None:
        s.delete(run)
    return roots


@router.post("/scan/{run_id}/delete")
def scan_delete(run_id: int):
    """删除扫描：级联删 change_event/raw_finding/进度 KV + run，并按根域连带删除资产。

    拒绝删除仍在跑的任务；已停止（cancelled）可立刻删。
    独占根域（无其它 ScanRun 引用）的资产与查询日志一并清掉。
    """
    with get_session() as s:
        run = s.get(ScanRun, run_id)
        if run is not None and _delete_blocked(run):
            return RedirectResponse(f"/scan/{run_id}", status_code=303)
        roots = _delete_run(s, run_id)
        # 共享根域留给其它仍在的任务；仅删独占根（项目 scope 不占数据）
        _delete_assets_exclusive(s, roots)
        exclusive = [
            r
            for r in roots
            if r and r not in _roots_still_referenced(s, roots)
        ]
        _delete_query_log(s, exclusive)
    return RedirectResponse("/scans/table", status_code=303)


@router.post("/scans/project/delete")
def project_delete(project_id: int = Form(...)):
    """删除整个项目：该项目名下全部扫描任务 + 按根域连带删除资产 + 项目记录本身。"""
    from radar.storage.models import Project

    with get_session() as s:
        proj = s.get(Project, project_id)
        if proj is None:
            return RedirectResponse("/scans/table", status_code=303)
        runs = (
            s.execute(select(ScanRun).where(ScanRun.project_id == project_id))
            .scalars()
            .all()
        )
        if any(_delete_blocked(r) for r in runs):
            return RedirectResponse("/scans/table", status_code=303)
        roots: list[str] = []
        for r in runs:
            roots.extend(r.roots or [])
        for r in runs:
            _delete_run(s, r.id)
        _delete_assets_exclusive(s, roots, exclude_project_id=project_id)
        _delete_query_log(s, [r for r in roots if r not in _roots_still_referenced(s, roots, exclude_project_id=project_id)])
        s.delete(proj)
    return RedirectResponse("/scans/table", status_code=303)


@router.post("/scan/{run_id}/stop")
def scan_stop(run_id: int):
    """停止扫描：标记 cancelled + 置取消标志；由 worker/pipeline 阶段检查收束。"""
    from datetime import UTC, datetime

    from radar.storage.db import kv_set
    from radar.sys_log import record_op

    with get_session() as s:
        # FOR UPDATE：与 claim_next_scan 互斥，避免 created→cancelled 与认领竞态
        run = s.execute(
            select(ScanRun).where(ScanRun.id == run_id).with_for_update()
        ).scalar_one_or_none()
        if run is not None and run.status in ("created", "running"):
            was_queued = run.status == "created"
            run.status = "cancelled"
            run.stats = {**(run.stats or {}), "stopped": True}
            if was_queued:
                # 排队未跑：无 worker 收尾，直接落 finished 以便立即删除
                run.finished_at = datetime.now(UTC).replace(tzinfo=None)
            else:
                kv_set(s, f"cancel_scan:{run_id}", {"cancelled": True})
            record_op(s, "scan.stop", f"#{run_id}")
    return RedirectResponse(f"/scan/{run_id}", status_code=303)


@router.post("/scan/{run_id}/rerun")
def scan_rerun(request: Request, run_id: int):
    """重跑：用相同 roots 入队新扫描。"""
    from radar.scan_dispatch import run_inline_if_needed
    from radar.storage.project_ops import can_scan_project
    from radar.storage.scan_queue import ScopeDenied, enqueue_scan

    with get_session() as s:
        run = s.get(ScanRun, run_id)
        if run is None:
            return RedirectResponse("/scans/table", status_code=303)
        if run.project_id:
            from radar.storage.models import Project

            proj = s.get(Project, run.project_id)
            if proj is not None:
                ok, _reason = can_scan_project(proj)
                if not ok:
                    return RedirectResponse(f"/scan/{run_id}?err=paused", status_code=303)
        roots = list(run.roots or [])
        # 历史 rerun 语义：sources=[] → pipeline 视为全部源
        try:
            new_id = enqueue_scan(
                s, roots=roots, project_id=run.project_id, sources=[], trigger="rerun"
            )
        except ScopeDenied:
            return RedirectResponse(f"/scan/{run_id}?err=scope", status_code=303)
    run_inline_if_needed(new_id, roots, [])
    return RedirectResponse(f"/scan/{new_id}", status_code=303)


@router.post("/scan/{run_id}/resume")
def scan_resume(request: Request, run_id: int):
    """续扫：同任务从断点接着跑（跳过已成功采集源）。"""
    from radar.scan_dispatch import run_inline_if_needed
    from radar.storage.project_ops import can_scan_project
    from radar.storage.scan_queue import enqueue_resume, sources_from_run

    with get_session() as s:
        run0 = s.get(ScanRun, run_id)
        if run0 is not None and run0.project_id:
            from radar.storage.models import Project

            proj = s.get(Project, run0.project_id)
            if proj is not None:
                ok, _reason = can_scan_project(proj)
                if not ok:
                    return RedirectResponse(f"/scan/{run_id}?err=paused", status_code=303)
        rid = enqueue_resume(s, run_id)
        if rid is None:
            return RedirectResponse(f"/scan/{run_id}", status_code=303)
        run = s.get(ScanRun, rid)
        roots = list(run.roots or [])
        sources = sources_from_run(run)
    run_inline_if_needed(rid, roots, sources)
    return RedirectResponse(f"/scan/{rid}", status_code=303)


@router.get("/scan/{run_id}", response_class=HTMLResponse)
def scan_detail(request: Request, run_id: int):
    from radar.storage.models import Project

    with get_session() as s:
        run = s.get(ScanRun, run_id)
        if run is None:
            return templates.TemplateResponse(
                request,
                "scan_detail.html",
                {
                    "request": request,
                    "run": None,
                    "stages": [],
                    "kpi": {},
                    "stage": "",
                    **view_context(s),
                },
                status_code=404,
            )
        project_name = None
        if run.project_id is not None:
            proj = s.get(Project, run.project_id)
            project_name = proj.name if proj is not None else None
        stats = run.stats or {}
        done = run.status in ("done", "failed", "partial", "cancelled", "interrupted")
        stages, kpi = _pipeline_view(stats, stats.get("stage", ""), done)
        return templates.TemplateResponse(
            request,
            "scan_detail.html",
            {
                "request": request,
                "run": run,
                "project_name": project_name,
                "stages": stages,
                "kpi": kpi,
                "stage": stats.get("stage", ""),
                "done": done,
                "total": kpi.get("total_found", 0),
                **view_context(s),
            },
        )


@router.get("/scan/{run_id}/log", response_class=HTMLResponse)
def scan_log(request: Request, run_id: int):
    """扫描日志（每源成功/失败/超时/熔断）；运行中 HTMX 定时尾部追加。"""
    with get_session() as s:
        run = s.get(ScanRun, run_id)
        if run is None:
            return templates.TemplateResponse(
                request,
                "scan_log.html",
                {"request": request, "run": None, "lines": [], "done": True, **view_context(s)},
                status_code=404,
            )
        ctx = {
            "request": request,
            "run": run,
            "lines": _log_lines(run),
            "done": run.status in ("done", "failed", "partial", "cancelled", "interrupted"),
            **view_context(s),
        }
        if request.headers.get("HX-Request"):
            return templates.TemplateResponse(request, "partials/scan_log.html", ctx)
        return templates.TemplateResponse(request, "scan_log.html", ctx)


@router.get("/scan/{run_id}/partial", response_class=HTMLResponse)
def scan_partial(request: Request, run_id: int):
    from radar.storage.db import kv_get

    with get_session() as s:
        run = s.get(ScanRun, run_id)
        done = run is None or run.status in (
            "done",
            "failed",
            "partial",
            "cancelled",
            "interrupted",
        )
        prog = kv_get(s, f"scan_progress:{run_id}") or {}
        prog_sources = prog.get("sources") or {}
        stats = (run.stats if run else None) or {}
        stage = stats.get("stage", "")
        # 运行中合并 collect 实时进度；结束后只用落库 stats
        live_prog = None if done else (prog_sources or None)
        stages, kpi = _pipeline_view(stats, stage, done, prog_sources=live_prog)
        return templates.TemplateResponse(
            request,
            "partials/scan_status.html",
            {
                "request": request,
                "run": run,
                "stages": stages,
                "kpi": kpi,
                "done": done,
                "stage": stage,
                "total": kpi.get("total_found", 0),
            },
        )


@router.get("/scan-sidebar", response_class=HTMLResponse)
def scan_sidebar(request: Request):
    """侧栏「最近扫描」片段：仅扫描中由 base.html 每 3s 轮询；结束后 OOB 停轮询。"""
    from radar.server.deps import view_context_lite

    with get_session() as s:
        ctx = view_context_lite(s, request)
    return templates.TemplateResponse(
        request,
        "partials/scan_sidebar.html",
        {
            "request": request,
            "recent_runs": ctx["recent_runs"],
            "running": ctx["running"],
        },
    )
