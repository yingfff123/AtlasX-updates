"""设置页：所有 key 的唯一入口，保存即测即生效。"""

from __future__ import annotations

import hashlib
from pathlib import Path

import httpx
from fastapi import APIRouter, Form, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from sqlalchemy import select

from radar.llm.base import (
    Message,
    configure_provider,
    format_llm_http_error,
    get_provider,
    normalize_api_key,
)
from radar.llm.guard import get_budget
from radar.server.deps import get_session, view_context
from radar.server.proxy import PROXY_KEY, apply_to_env
from radar.server.templates_env import templates
from radar.storage import crypto
from radar.storage.db import kv_get, kv_get_row, kv_set
from radar.storage.models import Credential

router = APIRouter()


def _probe(kind: str, secret: str) -> tuple[str, str]:
    """按 kind 发最小请求验证 key。返回 (status, hint)。"""
    try:
        if kind == "fofa":
            from radar.collectors.fofa import parse_fofa_cred, verify_key

            email, key, base = parse_fofa_cred(secret)
            ok, hint = verify_key(email, key, base)
            return ("ok" if ok else "error", hint)
        if kind == "quake":
            r = httpx.get(
                "https://quake.360.net/api/v3/user/info",
                headers={"X-QuakeToken": secret},
                timeout=15.0,
            )
            return ("ok" if r.status_code == 200 else "error", str(r.status_code))
        if kind == "hunter":
            import base64 as _b64

            q = _b64.urlsafe_b64encode(b'domain="example.com"').decode().rstrip("=")
            r = httpx.get(
                "https://hunter.qianxin.com/openApi/search",
                params={
                    "api-key": secret.strip(),
                    "search": q,
                    "page": 1,
                    "page_size": 1,
                    "is_web": 3,
                },
                timeout=15.0,
            )
            code = r.json().get("code") if r.status_code == 200 else None
            return ("ok" if code == 200 else "error", str(code or r.status_code))
        if kind == "crawlora_bing":
            r = httpx.get(
                "https://api.crawlora.net/api/v1/bing/search",
                params={"q": "site:example.com", "count": 1},
                headers={"x-api-key": secret.strip()},
                timeout=15.0,
            )
            data = r.json() if r.status_code == 200 else {}
            if r.status_code == 401 or data.get("code") == 401:
                return ("error", "key 无效（401）")
            if r.status_code == 400 or data.get("code") == 400:
                # site: 被拒 → 用普通关键词验证 key 有效性
                r2 = httpx.get(
                    "https://api.crawlora.net/api/v1/bing/search",
                    params={"q": "test", "count": 1},
                    headers={"x-api-key": secret.strip()},
                    timeout=15.0,
                )
                d2 = r2.json() if r2.status_code == 200 else {}
                return (
                    "ok" if d2.get("code") == 200 else "error",
                    f"site:受限，普通查询 {r2.status_code}",
                )
            return ("ok" if data.get("code") == 200 else "error", str(r.status_code))
        if kind == "shodan":
            r = httpx.get("https://api.shodan.io/api-info", params={"key": secret}, timeout=15.0)
            return ("ok" if r.status_code == 200 else "error", str(r.status_code))
        if kind == "censys":
            secret = secret.strip()
            if "," not in secret:
                # 新 Platform API：censys_ 开头的 Personal Access Token（Bearer 认证）
                # 免费账号无 Organization ID，搜索 403，但单主机查询 200 可验证 token 有效性
                r = httpx.get(
                    "https://api.platform.censys.io/v3/global/asset/host/1.1.1.1",
                    headers={"Authorization": f"Bearer {secret}"},
                    timeout=15.0,
                )
                if r.status_code == 200:
                    return ("ok", "token 有效（免费账号仅单点查询）")
                return ("error", f"{r.status_code}：token 无效或账号无 API 权限")
            # 旧 Search API：API-ID,API-SECRET（Basic auth）；account 端点只有 v1
            api_id, _, api_secret = secret.partition(",")
            r = httpx.get(
                "https://search.censys.io/api/v1/account", auth=(api_id, api_secret), timeout=15.0
            )
            return ("ok" if r.status_code == 200 else "error", str(r.status_code))
        if kind == "firefly":
            from radar.collectors.firefly import verify_key

            ok, hint = verify_key(secret.strip())
            return ("ok" if ok else "error", hint)
        if kind == "zoomeye":
            from radar.collectors.zoomeye import verify_key

            ok, hint = verify_key(secret.strip())
            return ("ok" if ok else "error", hint)
        if kind == "daydaymap":
            from radar.collectors.daydaymap import verify_key

            ok, hint = verify_key(secret.strip())
            return ("ok" if ok else "error", hint)
        if kind == "zone0":
            from radar.collectors.zone0 import verify_key

            ok, hint = verify_key(secret.strip())
            return ("ok" if ok else "error", hint)
        if kind == "virustotal":
            from radar.collectors.virustotal import verify_key

            ok, hint = verify_key(secret.strip())
            return ("ok" if ok else "error", hint)
        return ("ok", "免验证")
    except Exception as exc:  # noqa: BLE001
        return ("error", repr(exc)[:80])


_SETTINGS_SECTIONS = {
    "appearance": "外观",
    "credentials": "凭据",
    "network": "网络",
    "scan": "扫描策略",
    "agent": "Agent",
    "logs": "日志",
    "system": "系统",
    "users": "用户",
}


@router.get("/settings", response_class=HTMLResponse)
def settings_page(
    request: Request,
    tab: str = "appearance",
    log_kind: str = "ops",
    level: str | None = None,
):
    if tab not in _SETTINGS_SECTIONS:
        return RedirectResponse("/settings?tab=appearance", status_code=303)
    actor = getattr(request.state, "user", None)
    if tab == "users" and actor is not None and getattr(actor, "is_analyst", False):
        return RedirectResponse("/settings?tab=scan", status_code=303)
    with get_session() as s:
        all_creds = s.execute(select(Credential).order_by(Credential.id)).scalars().all()
        creds = [c for c in all_creds if c.kind != "query_api"]
        query_tokens = [c for c in all_creds if c.kind == "query_api"]
        from radar.server.query_api_auth import owner_usernames, pop_flash_viewer_token

        token_owners = owner_usernames(s, query_tokens)
        flash_viewer_qapi = pop_flash_viewer_token(request) if tab == "users" else None
        provider = get_provider()
        budget = get_budget()
        cfg = kv_get(s, "llm_config") or {}
        llm_state = {
            "provider": provider.name,
            "model": provider.default_model() if provider.name != "none" else "—",
            "model_large": provider.model_for_tier("large") if provider.name != "none" else "—",
            "configured": provider.name != "none",
            "tokens_used": budget.used,
            "budget": budget.daily_limit,
            "form_provider": cfg.get("provider") or "none",
            "form_base_url": cfg.get("base_url") or "",
            "form_model_small": cfg.get("model_small") or "",
            "form_model_large": cfg.get("model_large") or "",
        }
        proxy_url = (kv_get(s, PROXY_KEY) or {}).get("url", "")
        sched_time = (kv_get(s, "schedule_config") or {}).get("time", "03:00")
        from radar.core.active_scan import active_scan_opts
        from radar.enrichers.paths import js_crawl_opts

        js_crawl = js_crawl_opts(s)
        js_deep = js_crawl["deep"]
        active_scan = active_scan_opts(s)

        dd_raw = kv_get(s, "deep_dive_config") or {}
        if not isinstance(dd_raw, dict):
            dd_raw = {}
        from radar.agents.deep_llm import DEFAULT_LLM_CAP_FULL, resolve_llm_mode
        from radar.license import is_pro
        from radar.pro import has_pro_payload

        # Community：运行时强制关闭深挖展示/生效，但 **不写回 KV**。
        # 否则升 Pro 后仍残留 enabled=false，Pro 独有能力被配置锁死。
        # is_pro() 不传页面 session，避免远端校验持事务等网络
        dd_effective = dict(dd_raw)
        if not is_pro() or not has_pro_payload():
            dd_effective = {
                **dd_effective,
                "enabled": False,
                "llm_mode": "off",
                "llm_enabled": False,
            }

        llm_mode = resolve_llm_mode(dd_effective)
        default_llm_cap = DEFAULT_LLM_CAP_FULL if llm_mode == "full" else 15
        from radar.storage.deep_control import is_deep_paused
        from radar.storage.report_config import get_report_config

        deep_dive_paused = is_deep_paused(s)
        report_cfg = get_report_config(s)
        deep_dive_cfg = {
            "enabled": dd_effective.get("enabled", True) is not False,
            "cap": int(dd_effective.get("cap") or 8),
            "unauth_limit": int(dd_effective.get("unauth_limit") or 12),
            "allow_nacos_probe": bool(dd_effective.get("allow_nacos_probe")),
            "llm_mode": llm_mode,
            "llm_enabled": llm_mode != "off",
            "llm_cap_per_run": int(
                dd_effective["llm_cap_per_run"]
                if dd_effective.get("llm_cap_per_run") is not None
                else default_llm_cap
            ),
            "manual_daily_cap": int(dd_effective.get("manual_daily_cap") or 20),
        }

        logs_ctx: dict = {
            "log_kind": "ops",
            "ops_logs": [],
            "runtime_logs": [],
            "runtime_level": "",
        }
        if tab == "logs":
            logs_ctx.update(_load_logs_ctx(s, log_kind=log_kind, level=level))

        system_ctx: dict = {}
        if tab == "system":
            from radar.config import settings as app_settings
            from radar.license.status import license_status_full
            from radar.update import UPDATES_DIR, current_version

            packs = sorted(UPDATES_DIR.glob("*.zip"), key=lambda p: p.stat().st_mtime, reverse=True)[
                :8
            ] if UPDATES_DIR.is_dir() else []
            lic = license_status_full(session=s)
            system_ctx = {
                "app_version": current_version(),
                "update_channel": (app_settings.update_channel_url or "").strip()
                or f"github:{app_settings.update_github_repo}",
                "update_download_hint": (
                    "https://github.com/yingfff123/AtlasX-updates/releases/latest/download/atlasx-upgrade.zip"
                ),
                "update_releases_url": "https://github.com/yingfff123/AtlasX-updates/releases",
                "local_packs": [
                    {
                        "name": p.name,
                        "size": p.stat().st_size,
                        "mtime": int(p.stat().st_mtime),
                        "sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
                    }
                    for p in packs
                ],
                "license": lic,
            }

        users_ctx: dict = {"users": [], "users_error": None}
        if tab == "users":
            from radar.storage.models import AppUser

            users_ctx["users"] = (
                s.execute(select(AppUser).order_by(AppUser.id)).scalars().all()
            )

        from radar.server.cred_portals import portals_json

        return templates.TemplateResponse(
            request,
            "settings.html",
            {
                "request": request,
                "section": tab,
                "section_title": _SETTINGS_SECTIONS[tab],
                "creds": creds,
                "query_tokens": query_tokens,
                "token_owners": token_owners,
                "flash_viewer_qapi": flash_viewer_qapi,
                "cred_portals": portals_json(),
                "llm": llm_state,
                "proxy_url": proxy_url,
                "sched_time": sched_time,
                "js_crawl_deep": js_deep,
                "js_crawl": js_crawl,
                "active_scan": active_scan,
                "deep_dive_cfg": deep_dive_cfg,
                "deep_dive_paused": deep_dive_paused,
                "report_cfg": report_cfg,
                **logs_ctx,
                **system_ctx,
                **users_ctx,
                **view_context(s),
            },
        )


def _load_logs_ctx(
    s,
    *,
    log_kind: str = "ops",
    level: str | None = None,
) -> dict:
    """操作日志=sys_log.record_op；运行日志=logging ring buffer。"""
    from radar.sys_log import list_ops, list_runtime

    kind = log_kind if log_kind in ("ops", "runtime") else "ops"
    lvl = (level or "").strip().lower() or None
    if lvl == "warning":
        lvl = "warn"
    if lvl not in (None, "info", "warn", "error", "debug", "critical"):
        lvl = None
    return {
        "log_kind": kind,
        "ops_logs": list_ops(s, limit=200),
        "runtime_logs": list_runtime(limit=500, level=lvl),
        "runtime_level": lvl or "",
    }


@router.get("/settings/logs/runtime", response_class=HTMLResponse)
def settings_runtime_log_partial(request: Request, level: str | None = None):
    """HTMX 轮询片段：仅运行日志表体。"""
    from radar.sys_log import list_runtime

    lvl = (level or "").strip().lower() or None
    if lvl == "warning":
        lvl = "warn"
    rows = list_runtime(limit=500, level=lvl if lvl in ("info", "warn", "error", "debug", "critical") else None)
    return templates.TemplateResponse(
        request,
        "partials/runtime_log.html",
        {"request": request, "runtime_logs": rows, "runtime_level": lvl or ""},
    )


@router.post("/settings/logs/clear")
def clear_logs(log_kind: str = Form("ops")):
    """清空操作日志或运行日志缓冲。"""
    kind = log_kind if log_kind in ("ops", "runtime") else "ops"
    if kind == "runtime":
        from radar.sys_log import clear_runtime

        clear_runtime()
    else:
        from radar.sys_log import clear_ops, record_op

        with get_session() as s:
            clear_ops(s)
            record_op(s, "logs.clear", "清空操作日志")
    return RedirectResponse(f"/settings?tab=logs&log_kind={kind}", status_code=303)


@router.get("/settings/logs/export")
def export_ops_logs(q: str | None = None, format: str = "json"):
    """Pro 审计导出：q=deep_dive|license|query_api。"""
    import csv
    import io
    import json as _json

    from fastapi.responses import Response

    from radar.license.http import ensure_pro
    from radar.sys_log import list_ops

    denied = ensure_pro("audit_export")
    if denied is not None:
        return denied
    fmt = (format or "json").lower().strip()
    if fmt not in ("json", "csv"):
        fmt = "json"
    with get_session() as s:
        rows = list_ops(s, limit=500, q=q)
    if fmt == "csv":
        buf = io.StringIO()
        writer = csv.writer(buf)
        writer.writerow(["id", "t", "level", "action", "detail"])
        for row in rows:
            writer.writerow(
                [
                    row.get("id", ""),
                    row.get("t", ""),
                    row.get("level", ""),
                    row.get("action", ""),
                    row.get("detail", ""),
                ]
            )
        return Response(
            buf.getvalue(),
            media_type="text/csv; charset=utf-8",
            headers={"Content-Disposition": 'attachment; filename="ops-audit.csv"'},
        )
    return Response(
        _json.dumps({"q": q or "", "count": len(rows), "items": rows}, ensure_ascii=False, indent=2),
        media_type="application/json; charset=utf-8",
        headers={"Content-Disposition": 'attachment; filename="ops-audit.json"'},
    )


@router.get("/settings/{section}", response_class=HTMLResponse)
def settings_section_compat(section: str):
    """旧路径 /settings/appearance → /settings?tab=appearance。"""
    tab = section if section in _SETTINGS_SECTIONS else "appearance"
    return RedirectResponse(f"/settings?tab={tab}", status_code=303)


@router.post("/settings/schedule")
def save_schedule(sched_time: str = Form("03:00")):
    """保存每日调度时间（radar schedule CLI 读取）。"""
    import re as _re

    if not _re.fullmatch(r"([01]?\d|2[0-3]):[0-5]\d", sched_time.strip()):
        sched_time = "03:00"
    with get_session() as s:
        kv_set(s, "schedule_config", {"time": sched_time.strip()})
        from radar.sys_log import record_op

        record_op(s, "settings.schedule", f"time={sched_time.strip()}")
    return RedirectResponse("/settings?tab=scan", status_code=303)


@router.post("/settings/proxy")
def save_proxy(proxy_url: str = Form("")):
    """代理保存即生效：写 kv + 同步环境变量（httpx trust_env 自动走）。"""
    from radar.server.proxy import validate_proxy_url

    raw = (proxy_url or "").strip()
    if raw:
        ok = validate_proxy_url(raw)
        if ok is None:
            return RedirectResponse("/settings?tab=network&err=proxy", status_code=303)
        raw = ok
    with get_session() as s:
        if raw:
            kv_set(s, PROXY_KEY, {"url": raw})
        else:
            row = kv_get_row(s, PROXY_KEY)
            if row is not None:
                s.delete(row)
        from radar.sys_log import record_op

        record_op(
            s,
            "settings.proxy",
            "enabled" if raw else "disabled",
        )
    apply_to_env(raw)
    return RedirectResponse("/settings?tab=network", status_code=303)


@router.post("/settings/active-scan")
async def save_active_scan(request: Request):
    """主动扫描：OneForAll / 主动指纹 / 目录扫（CE+Pro，默认全开）。

    checkbox 未勾选不会出现在 form 里 → bool(None)=False，三键每次全量写入。
    """
    form = await request.form()
    from radar.core.active_scan import ACTIVE_SCAN_KEY

    # 显式三键，避免 normalize「缺键回默认 True」在未来误用时把关写成开
    cfg = {
        "oneforall": bool(form.get("oneforall")),
        "active_finger": bool(form.get("active_finger")),
        "dir_scan": bool(form.get("dir_scan")),
    }
    with get_session() as s:
        kv_set(s, ACTIVE_SCAN_KEY, cfg)
        # 兼容旧 js_crawl.probe：与主动指纹对齐
        prev = kv_get(s, "js_crawl_config") or {}
        if not isinstance(prev, dict):
            prev = {}
        kv_set(
            s,
            "js_crawl_config",
            {
                "deep": bool(prev.get("deep")),
                "wayback": bool(prev.get("wayback")),
                "probe": bool(cfg["active_finger"]),
            },
        )
        from radar.sys_log import record_op

        record_op(
            s,
            "settings.active_scan",
            f"oneforall={'on' if cfg['oneforall'] else 'off'} "
            f"active_finger={'on' if cfg['active_finger'] else 'off'} "
            f"dir_scan={'on' if cfg['dir_scan'] else 'off'}",
        )
    return RedirectResponse("/settings?tab=scan", status_code=303)


@router.post("/settings/js-crawl")
async def save_js_crawl(request: Request):
    """JS 爬取开关（深爬 / Wayback）。probe 已迁到主动扫描。"""
    form = await request.form()
    with get_session() as s:
        prev = kv_get(s, "js_crawl_config") or {}
        if not isinstance(prev, dict):
            prev = {}
        from radar.core.active_scan import active_scan_opts

        finger = active_scan_opts(s).get("active_finger", True)
        deep = bool(form.get("deep"))
        if "js_crawl_v2" in form or "wayback" in form:
            wayback = bool(form.get("wayback"))
        else:
            wayback = bool(prev.get("wayback"))
        cfg = {"deep": deep, "wayback": wayback, "probe": finger}
        kv_set(s, "js_crawl_config", cfg)
        from radar.sys_log import record_op

        record_op(
            s,
            "settings.js_crawl",
            f"deep={'on' if cfg['deep'] else 'off'} "
            f"wayback={'on' if cfg['wayback'] else 'off'}",
        )
    return RedirectResponse("/settings?tab=scan", status_code=303)


@router.post("/settings/deep-dive")
def save_deep_dive(
    enabled: str = Form(""),
    cap: str = Form("8"),
    unauth_limit: str = Form("12"),
    allow_nacos_probe: str = Form(""),
    llm_mode: str = Form("off"),
    llm_enabled: str = Form(""),  # 兼容旧表单
    llm_cap_per_run: str = Form("15"),
    manual_daily_cap: str = Form("20"),
):
    """深挖（tonight 作业单）配置。无 Pro 一律拒绝写入。"""
    from radar.license.http import ensure_pro

    denied = ensure_pro("deep_dive", redirect="/settings?tab=scan")
    if denied is not None:
        return denied

    def _int(raw: str, default: int, lo: int, hi: int) -> int:
        try:
            n = int(str(raw).strip())
        except (TypeError, ValueError):
            return default
        return max(lo, min(hi, n))

    from radar.agents.deep_llm import DEFAULT_LLM_CAP_FULL, resolve_llm_mode

    mode = str(llm_mode or "").strip().lower()
    if mode not in ("off", "host_only", "full"):
        # 旧 checkbox：勾选 → host_only
        mode = "host_only" if llm_enabled else "off"
    mode = resolve_llm_mode({"llm_mode": mode})
    default_cap = DEFAULT_LLM_CAP_FULL if mode == "full" else 15
    cfg = {
        "enabled": bool(enabled),
        "cap": _int(cap, 8, 1, 32),
        "unauth_limit": _int(unauth_limit, 12, 1, 40),
        "allow_nacos_probe": bool(allow_nacos_probe),
        "llm_mode": mode,
        "llm_enabled": mode != "off",
        "llm_cap_per_run": _int(llm_cap_per_run, default_cap, 0, 200),
        "manual_daily_cap": _int(manual_daily_cap, 20, 0, 200),
        "wayback": False,
    }
    with get_session() as s:
        kv_set(s, "deep_dive_config", cfg)
        from radar.sys_log import record_op

        record_op(
            s,
            "settings.deep_dive",
            f"enabled={cfg['enabled']} cap={cfg['cap']} llm_mode={cfg['llm_mode']}",
        )
    return RedirectResponse("/settings?tab=scan", status_code=303)


@router.post("/settings/report-config")
def save_report_config_route(
    enabled: str = Form(""),
    default_org_display_name: str = Form(""),
    include_phenomenon_t1: str = Form(""),
    include_phenomenon_t2: str = Form(""),
    include_t3_excluded_appendix: str = Form(""),
    include_scope_roots: str = Form(""),
    include_scan_method: str = Form(""),
    footer_disclaimer: str = Form(""),
):
    from radar.license.http import ensure_pro
    from radar.storage.report_config import save_report_config
    from radar.sys_log import record_op

    denied = ensure_pro("report_export", redirect="/settings?tab=scan")
    if denied is not None:
        return denied
    with get_session() as s:
        save_report_config(
            s,
            {
                "enabled": bool(enabled),
                "default_org_display_name": default_org_display_name,
                "include_phenomenon_t1": bool(include_phenomenon_t1),
                "include_phenomenon_t2": bool(include_phenomenon_t2),
                "include_t3_excluded_appendix": bool(include_t3_excluded_appendix),
                "include_scope_roots": bool(include_scope_roots),
                "include_scan_method": bool(include_scan_method),
                "footer_disclaimer": footer_disclaimer,
            },
        )
        record_op(s, "settings.report_config", f"enabled={bool(enabled)}")
    return RedirectResponse("/settings?tab=scan", status_code=303)


def _safe_post_next(raw: str) -> str:
    path = (raw or "").strip()
    if path.startswith("/scan/") and "://" not in path and "\\" not in path:
        return path.split("?")[0][:80]
    return "/settings?tab=scan"


@router.post("/settings/deep-dive/pause")
def pause_deep_dive(next: str = Form("")):
    from radar.license.http import ensure_pro
    from radar.storage.deep_control import set_deep_paused
    from radar.sys_log import record_op

    dest = _safe_post_next(next)
    denied = ensure_pro("probe_governance", redirect=dest)
    if denied is not None:
        return denied
    with get_session() as s:
        set_deep_paused(s, True)
        record_op(s, "deep_dive.pause", "paused=1")
    return RedirectResponse(dest, status_code=303)


@router.post("/settings/deep-dive/resume")
def resume_deep_dive():
    from radar.license.http import ensure_pro
    from radar.storage.deep_control import set_deep_paused
    from radar.sys_log import record_op

    denied = ensure_pro("probe_governance", redirect="/settings?tab=scan")
    if denied is not None:
        return denied
    with get_session() as s:
        set_deep_paused(s, False)
        record_op(s, "deep_dive.resume", "paused=0")
    return RedirectResponse("/settings?tab=scan", status_code=303)


@router.post("/settings/llm")
def save_llm(
    provider: str = Form(...),
    api_key: str = Form(""),
    base_url: str = Form(""),
    model_small: str = Form(""),
    model_large: str = Form(""),
    daily_token_budget: str = Form(""),
):
    """AI 配置在线保存：provider/base/model/日预算存 kv，key Fernet 加密存 Credential，保存即生效。"""
    from radar.llm.guard import clamp_daily_limit, resolve_daily_limit

    with get_session() as s:
        prev = kv_get(s, "llm_config") or {}
        if not isinstance(prev, dict):
            prev = {}
        cfg = {
            **prev,
            "provider": provider.strip(),
            "base_url": base_url.strip(),
            "model_small": model_small.strip(),
            "model_large": model_large.strip(),
        }
        raw_budget = (daily_token_budget or "").strip().replace(",", "")
        if raw_budget != "":
            try:
                cfg["daily_token_budget"] = clamp_daily_limit(raw_budget)
            except (TypeError, ValueError):
                pass  # 非法数字：保留旧上限
        kv_set(s, "llm_config", cfg)
        if api_key.strip():
            key = normalize_api_key(api_key)
            cred = s.execute(select(Credential).where(Credential.kind == "llm")).scalars().first()
            if cred is None:
                s.add(
                    Credential(
                        kind="llm",
                        secret_encrypted=crypto.encrypt(key),
                        key_hint=crypto.key_hint(key),
                        enabled=True,
                    )
                )
            else:
                cred.secret_encrypted = crypto.encrypt(key)
                cred.key_hint = crypto.key_hint(key)
    # 立即应用到运行中的 provider（key 从加密存储读回）
    with get_session() as s:
        cfg = kv_get(s, "llm_config") or {}
        cred = s.execute(select(Credential).where(Credential.kind == "llm")).scalars().first()
        key = crypto.decrypt(cred.secret_encrypted) if cred else ""
        configure_provider(
            cfg.get("provider"), cfg.get("base_url", ""), key, cfg.get("model_small", ""),
            cfg.get("model_large", ""),
        )
        # 刷新进程内日预算上限
        get_budget().daily_limit = resolve_daily_limit()
        from radar.sys_log import record_op

        record_op(
            s,
            "settings.llm",
            f"provider={cfg.get('provider') or 'none'} budget={resolve_daily_limit()}",
        )
    return RedirectResponse("/settings?tab=agent", status_code=303)


@router.post("/settings/llm/disable")
def disable_llm():
    """停用 AI（回落全规则降级）：清 provider/key，保留日 token 上限。"""
    from radar.llm.guard import clamp_daily_limit, get_budget, resolve_daily_limit

    with get_session() as s:
        prev = kv_get(s, "llm_config") or {}
        kept: dict = {}
        if isinstance(prev, dict) and prev.get("daily_token_budget") not in (None, ""):
            try:
                kept["daily_token_budget"] = clamp_daily_limit(prev.get("daily_token_budget"))
            except (TypeError, ValueError):
                pass
        if kept:
            kv_set(s, "llm_config", kept)
        else:
            row = kv_get_row(s, "llm_config")
            if row is not None:
                s.delete(row)
        for cred in s.execute(select(Credential).where(Credential.kind == "llm")).scalars():
            s.delete(cred)
        from radar.sys_log import record_op

        record_op(s, "settings.llm", "disabled")
    configure_provider("none")
    get_budget().daily_limit = resolve_daily_limit()
    return RedirectResponse("/settings?tab=agent", status_code=303)


@router.post("/settings/credentials/test")
def test_credential(kind: str = Form(...), secret: str = Form(...)):
    """未保存先测：对表单里的裸 key 发最小验证请求，不落库。"""
    status, detail = _probe(kind.strip(), secret)
    return JSONResponse({"status": status, "detail": detail})


@router.post("/settings/credentials/{cred_id}/test")
def test_saved_credential(cred_id: int):
    """后台测试已保存的 key：AJAX 调用，返回 JSON 不跳转，回写 last_status。"""
    with get_session() as s:
        cred = s.get(Credential, cred_id)
        if cred is None:
            return JSONResponse({"status": "error", "detail": "凭据已删除"})
        status, detail = _probe(cred.kind, crypto.decrypt(cred.secret_encrypted))
        cred.last_status = status
        return JSONResponse({"status": status, "detail": detail})


@router.post("/settings/llm/test")
def test_llm(
    provider: str = Form(...),
    api_key: str = Form(""),
    base_url: str = Form(""),
    model_small: str = Form(""),
    model_large: str = Form(""),
):
    """AI 配置连通性测试：用表单值构建 provider 发最小 chat 请求（key 留空则测已存的）。"""
    from radar.llm.base import (
        PROVIDER_PRESETS,
        OpenAICompatProvider,
    )

    name = provider.strip().lower()
    key = normalize_api_key(api_key)
    if not key:
        cred = s_query_llm_cred()
        if cred is None:
            return JSONResponse({"status": "error", "detail": "请先填 API key"})
        key = normalize_api_key(crypto.decrypt(cred.secret_encrypted))
    if name == "none":
        return JSONResponse({"status": "error", "detail": "请先选择 provider"})
    base = base_url.strip() or PROVIDER_PRESETS.get(name, {}).get("base_url", "")
    if not base:
        return JSONResponse({"status": "error", "detail": "该 provider 无预置 base_url，请填写"})
    p = OpenAICompatProvider(name, base, key, model_small.strip(), model_large.strip())
    try:
        res = p.chat(
            [
                Message(role="system", content='你是连通性测试端点。输出 JSON：{"ok": true}'),
                Message(role="user", content="ping"),
            ],
            model=p.default_model(),
            temperature=0.0,
            max_tokens=20,
        )
        return JSONResponse(
            {
                "status": "ok",
                "detail": f"{res.model} · {res.latency_ms}ms · tokens {res.tokens_out}",
            }
        )
    except Exception as exc:  # noqa: BLE001 - 连通性测试就是把异常变成可读结果
        return JSONResponse({"status": "error", "detail": format_llm_http_error(exc)[:160]})


def s_query_llm_cred():
    with get_session() as s:
        return s.execute(select(Credential).where(Credential.kind == "llm")).scalars().first()


@router.post("/settings/credentials")
def add_credential(request: Request, kind: str = Form(...), secret: str = Form(...)):
    kind = (kind or "").strip().lower()
    if kind == "query_api":
        return RedirectResponse("/settings?tab=credentials", status_code=303)
    with get_session() as s:
        s.add(
            Credential(
                kind=kind,
                secret_encrypted=crypto.encrypt(secret),
                key_hint=crypto.key_hint(secret),
                enabled=True,
            )
        )
        from radar.sys_log import record_op

        record_op(s, "credentials.add", f"kind={kind}")
    return RedirectResponse("/settings?tab=credentials", status_code=303)


@router.post("/settings/credentials/query-api/generate")
def generate_query_api_token(request: Request, label: str = Form("")):
    """生成查询 API Token；明文只返回这一次（入库为不可逆哈希）。

    管理员 → 共享 Token（owner=NULL）；非管理员 → 绑定自身（与 /query-api 一致）。
    """
    from radar.license.http import ensure_pro
    from radar.server.query_api_auth import (
        actor_is_admin,
        actor_user_id,
        build_usage_curls,
        create_query_api_credential,
        generate_token,
    )

    denied = ensure_pro("query_api")
    if denied is not None:
        return denied

    plain = generate_token()
    label_n = (label or "").strip()[:64] or None
    owner_id = None if actor_is_admin(request) else actor_user_id(request)
    if not actor_is_admin(request) and owner_id is None:
        return JSONResponse(
            {"status": "error", "detail": "无法确定当前用户，拒绝签发 Token"},
            status_code=403,
        )
    with get_session() as s:
        cred = create_query_api_credential(
            s, plain=plain, label=label_n, owner_user_id=owner_id
        )
        cred_id = int(cred.id)
        from radar.sys_log import record_op

        owner_tag = "shared" if owner_id is None else f"user:{owner_id}"
        record_op(s, "credentials.query_api.generate", f"id={cred_id} owner={owner_tag}")
    usage = build_usage_curls(plain)
    return JSONResponse(
        {
            "status": "ok",
            "id": cred_id,
            "token": plain,
            "key_hint": crypto.key_hint(plain),
            "label": label_n,
            "detail": "请立即复制保存；关闭后无法再查看明文",
            "usage": usage,
            "usage_text": "\n\n".join(usage),
        }
    )


@router.get("/settings/credentials/{cred_id}/query-api/usage")
def query_api_usage(request: Request, cred_id: int):
    """展开「用法」：仅占位符 curl，不再回显明文。"""
    from radar.license.http import ensure_pro
    from radar.server.query_api_auth import KIND, build_usage_curls, get_token_for_actor

    denied = ensure_pro("query_api")
    if denied is not None:
        return denied

    with get_session() as s:
        cred = get_token_for_actor(s, cred_id, request)
        if cred is None or cred.kind != KIND:
            return JSONResponse({"status": "error", "detail": "不是查询 API Token"}, status_code=404)
        hint = cred.key_hint
        label = cred.label
    base = str(request.base_url).rstrip("/")
    usage = build_usage_curls("$ASM_TOKEN", base)
    return JSONResponse(
        {
            "status": "ok",
            "id": cred_id,
            "label": label,
            "key_hint": hint,
            "token": None,
            "detail": "明文仅生成时展示一次；请将 $ASM_TOKEN 替换为本地保存的 Token",
            "usage": usage,
            "usage_text": "\n\n".join(usage),
        }
    )


@router.post("/settings/credentials/{cred_id}/verify")
def verify_credential(request: Request, cred_id: int):
    with get_session() as s:
        cred = s.get(Credential, cred_id)
        if cred is None:
            return RedirectResponse("/settings?tab=credentials", status_code=303)
        if cred.kind == "query_api":
            return JSONResponse(
                {"status": "error", "detail": "查询 API Token 不可在线探测（已哈希存储）"},
                status_code=400,
            )
        secret = crypto.decrypt(cred.secret_encrypted)
        status, detail = _probe(cred.kind, secret)
        cred.last_status = status
        return templates.TemplateResponse(
            request,
            "partials/cred_row.html",
            {"request": request, "cred": cred, "detail": detail, **_ctx(s)},
        )


@router.post("/settings/credentials/{cred_id}/toggle")
def toggle_credential(request: Request, cred_id: int):
    from radar.license.http import ensure_pro
    from radar.server.query_api_auth import KIND as QUERY_API_KIND
    from radar.server.query_api_auth import get_token_for_actor

    with get_session() as s:
        cred = s.get(Credential, cred_id)
        if cred is not None:
            if cred.kind == QUERY_API_KIND:
                denied = ensure_pro("query_api", redirect="/settings?tab=credentials")
                if denied is not None:
                    return denied
                if get_token_for_actor(s, cred_id, request) is None:
                    return RedirectResponse("/settings?tab=credentials", status_code=303)
            cred.enabled = not cred.enabled
            from radar.sys_log import record_op

            record_op(
                s,
                "credentials.toggle",
                f"id={cred_id} kind={cred.kind} enabled={cred.enabled}",
            )
    return RedirectResponse("/settings?tab=credentials", status_code=303)


@router.delete("/settings/credentials/{cred_id}")
def delete_credential(request: Request, cred_id: int):
    from radar.server.query_api_auth import KIND as QUERY_API_KIND
    from radar.server.query_api_auth import get_token_for_actor

    with get_session() as s:
        cred = s.get(Credential, cred_id)
        if cred is not None:
            if cred.kind == QUERY_API_KIND:
                from radar.license.http import ensure_pro

                denied = ensure_pro("query_api")
                if denied is not None:
                    return denied
                if get_token_for_actor(s, cred_id, request) is None:
                    return JSONResponse(
                        {"status": "error", "detail": "不是查询 API Token"},
                        status_code=404,
                    )
            kind = cred.kind
            s.delete(cred)
            from radar.sys_log import record_op

            record_op(s, "credentials.delete", f"id={cred_id} kind={kind}")
    # 前端 fetch 删除：返回 JSON，避免 303+reload 竞态
    return JSONResponse({"status": "ok", "id": cred_id})


def _ctx(s):
    return view_context(s)


@router.post("/settings/system/check")
def system_check_update():
    """检查是否有新版本（JSON）。"""
    from radar.update import check_latest

    info = check_latest()
    return JSONResponse(
        {
            "current": info.current,
            "latest": info.latest,
            "is_latest": info.is_latest,
            "update_available": info.update_available,
            "notes": info.notes,
            "download_url": info.download_url,
            "sha256": info.sha256,
            "channel": info.channel,
            "error": info.error,
        }
    )


def _activate_pro_license(raw: str, *, via: str) -> JSONResponse:
    """本机验签 + 远端一次绑定；成功才落库。"""
    from radar.license import invalidate
    from radar.license.activate import activate_remote, save_activation
    from radar.license.codec import verify_license_string
    from radar.license.store import save_raw
    from radar.sys_log import record_op

    raw = (raw or "").strip()
    if not raw:
        return JSONResponse({"status": "error", "detail": "请粘贴 License 串"}, status_code=400)
    verified = verify_license_string(raw)
    if not verified.get("valid"):
        reason = verified.get("reason") or "invalid"
        msg = {
            "bad_sig": "签名无效",
            "expired": "License 已过期",
            "malformed": "格式无效",
            "missing": "未提供",
        }.get(str(reason), f"无效（{reason}）")
        return JSONResponse({"status": "error", "detail": msg, "reason": reason}, status_code=400)

    remote = activate_remote(raw)
    if not remote.get("ok"):
        err = remote.get("error") or "activate_failed"
        detail = remote.get("detail") or "激活失败"
        if err == "already_used":
            detail = "此 License 已在其他机器使用，无法复用"
        elif err == "revoked":
            detail = "此 License 已被吊销"
        elif err == "not_issued":
            detail = "此 License 未登记或已删除，请使用管理台重新签发"
        elif err == "blocked":
            detail = "此 License 已删除/拉黑，无法再激活"
        elif err == "raw_mismatch":
            detail = "License 串与服务器记录不一致"
        elif err == "network":
            detail = remote.get("detail") or "无法连接 License 服务器"
        return JSONResponse(
            {"status": "error", "detail": detail, "reason": err},
            status_code=409 if err == "already_used" else 400,
        )

    from datetime import UTC, datetime

    with get_session() as s:
        save_raw(s, raw)
        save_activation(
            s,
            {
                "lid": verified.get("lid"),
                "machine_id": remote.get("machine_id"),
                "status": remote.get("status") or "activated",
                "last_ok_at": datetime.now(UTC).isoformat(),
            },
        )
        # 旧 CE 路径曾把 enabled=false 持久化；激活 Pro 时恢复默认可跑
        dd = kv_get(s, "deep_dive_config") or {}
        if isinstance(dd, dict) and dd.get("enabled") is False:
            dd = {**dd, "enabled": True}
            # 2.0：深 LLM 默认 off，激活 License 只恢复深挖开关，不偷开 LLM
            kv_set(s, "deep_dive_config", dd)
        record_op(s, f"system.license.{via}", f"lid={verified.get('lid')}")
    invalidate()
    return JSONResponse(
        {
            "status": "ok",
            "edition": "pro",
            "lid": verified.get("lid"),
            "exp": verified.get("exp"),
            "machine_id": remote.get("machine_id"),
            "detail": "已激活 Pro（已绑定本机）",
        }
    )


@router.post("/settings/system/license")
async def system_license_activate(request: Request):
    """粘贴激活 Pro License。"""
    form = await request.form()
    raw = str(form.get("raw") or "").strip()
    return _activate_pro_license(raw, via="activate")


@router.post("/settings/system/license/clear")
def system_license_clear():
    """清除已保存的 License → Community。"""
    from radar.license import invalidate
    from radar.license.activate import clear_activation
    from radar.license.store import clear_raw
    from radar.sys_log import record_op

    with get_session() as s:
        clear_raw(s)
        clear_activation(s)
        record_op(s, "system.license.clear", "→ community")
    invalidate()
    return JSONResponse({"status": "ok", "edition": "community", "detail": "已清除 License"})


@router.post("/settings/system/license/upload")
async def system_license_upload(request: Request):
    """上传 .lic / .txt 文件激活。"""
    form = await request.form()
    upload = form.get("file")
    if upload is None or not hasattr(upload, "read"):
        return JSONResponse({"status": "error", "detail": "请选择文件"}, status_code=400)
    data = await upload.read()  # type: ignore[misc]
    try:
        raw = data.decode("utf-8")
    except UnicodeDecodeError:
        return JSONResponse({"status": "error", "detail": "文件不是 UTF-8 文本"}, status_code=400)
    return _activate_pro_license(raw.strip(), via="upload")


@router.post("/settings/system/download")
async def system_download_pack(request: Request):
    """从更新通道下载升级包到本地 var/updates/。"""
    from radar.update import download_upgrade_pack

    form = await request.form()
    url = str(form.get("url") or "").strip()
    sha256 = str(form.get("sha256") or "").strip()
    if not url:
        return JSONResponse({"status": "error", "detail": "缺少 download url"}, status_code=400)
    try:
        path = download_upgrade_pack(url, expected_sha256=sha256)
    except Exception as exc:  # noqa: BLE001
        return JSONResponse({"status": "error", "detail": str(exc)[:200]}, status_code=400)
    with get_session() as s:
        from radar.sys_log import record_op

        record_op(s, "system.download", f"pack={path.name}")
    return JSONResponse(
        {
            "status": "ok",
            "detail": path.name,
            "path": str(path),
            "size": path.stat().st_size,
        }
    )


@router.post("/settings/system/upgrade")
async def system_apply_upgrade(request: Request):
    """上传或选用本地升级包并应用。表单：file= 或 pack_name=；sha256 可选。成功后自动重启。"""
    from radar.update import UPDATES_DIR, apply_upgrade_pack, resolve_pack_digest, schedule_service_restart

    form = await request.form()
    pack_name = str(form.get("pack_name") or "").strip()
    allow = str(form.get("allow_downgrade") or "") in ("1", "true", "on")
    expected_sha = str(form.get("sha256") or "").strip()
    auto_restart = str(form.get("auto_restart") or "1") not in ("0", "false", "off", "no")
    raw: bytes | None = None
    source = ""

    upload = form.get("file")
    if upload is not None and hasattr(upload, "read"):
        data = await upload.read()  # type: ignore[union-attr]
        if isinstance(data, str):
            data = data.encode()
        raw = bytes(data)
        source = getattr(upload, "filename", None) or "upload.zip"
    elif pack_name:
        # 仅允许 var/updates 下的纯文件名
        safe = Path(pack_name).name
        if safe != pack_name or "/" in pack_name or "\\" in pack_name or ".." in pack_name:
            return JSONResponse({"status": "error", "detail": "非法包名"}, status_code=400)
        path = UPDATES_DIR / safe
        if not path.is_file():
            return JSONResponse({"status": "error", "detail": "本地升级包不存在"}, status_code=404)
        raw = path.read_bytes()
        source = safe
    else:
        return JSONResponse({"status": "error", "detail": "请上传或选择升级包"}, status_code=400)

    try:
        digest = resolve_pack_digest(raw, expected_sha)
        # 用户点了应用：同版本补丁也放行
        result = apply_upgrade_pack(raw, allow_downgrade=allow, allow_same=True)
    except Exception as exc:  # noqa: BLE001
        return JSONResponse({"status": "error", "detail": str(exc)[:300]}, status_code=400)

    with get_session() as s:
        from radar.sys_log import record_op

        record_op(
            s,
            "system.upgrade",
            f"version={result['version']} files={result['file_count']} source={source} "
            f"sha256={digest[:12]} restart={'1' if auto_restart else '0'}",
        )
    if auto_restart:
        schedule_service_restart(delay_sec=1.5)
    detail = (
        f"已升级到 {result['version']}，正在自动重启…"
        if auto_restart
        else f"已升级到 {result['version']}，请重启服务生效"
    )
    return JSONResponse(
        {
            "status": "ok",
            "detail": detail,
            "version": result["version"],
            "file_count": result["file_count"],
            "restart_required": True,
            "restarting": auto_restart,
        }
    )


# ─── 用户管理（设置 → 用户）──────────────────────────────────────────


def _normalize_username(raw: str) -> str:
    return (raw or "").strip().lower()


def _admin_count(s) -> int:
    from sqlalchemy import func

    from radar.auth.rbac import ROLE_ADMIN
    from radar.storage.models import AppUser

    return (
        s.execute(
            select(func.count())
            .select_from(AppUser)
            .where(AppUser.role == ROLE_ADMIN, AppUser.enabled.is_(True))
        ).scalar()
        or 0
    )


@router.post("/settings/users")
def create_user(
    request: Request,
    username: str = Form(...),
    password: str = Form(...),
    role: str = Form("viewer"),
):
    from sqlalchemy import func

    from radar.auth.passwords import hash_password
    from radar.auth.rbac import (
        ROLE_ADMIN,
        ROLE_ANALYST,
        ROLE_VIEWER,
        VALID_ROLES,
        invalidate_users_exist_cache,
    )
    from radar.storage.models import AppUser
    from radar.sys_log import record_op

    name = _normalize_username(username)
    role_v = (role or ROLE_VIEWER).strip().lower()
    if role_v not in VALID_ROLES:
        role_v = ROLE_VIEWER
    if not name or len(name) < 2:
        return RedirectResponse("/settings?tab=users&err=username", status_code=303)
    try:
        pw_hash = hash_password(password)
    except ValueError:
        return RedirectResponse("/settings?tab=users&err=password", status_code=303)

    with get_session() as s:
        exists = s.execute(
            select(AppUser).where(AppUser.username == name)
        ).scalar_one_or_none()
        if exists is not None:
            return RedirectResponse("/settings?tab=users&err=exists", status_code=303)
        # 首个用户强制 admin，避免建完 viewer 把自己锁死
        n = s.execute(select(func.count()).select_from(AppUser)).scalar() or 0
        if n == 0:
            role_v = ROLE_ADMIN
        u = AppUser(username=name, password_hash=pw_hash, role=role_v, enabled=True)
        s.add(u)
        s.flush()
        record_op(s, "users.create", f"{name} role={role_v}")
        uid = int(u.id)
        # 普通用户：自动签发专属查询 API Token（明文仅本页闪一次）
        if role_v in (ROLE_VIEWER, ROLE_ANALYST):
            from radar.server.query_api_auth import (
                provision_viewer_query_token,
                set_flash_viewer_token,
            )

            plain, cred = provision_viewer_query_token(
                s, user_id=uid, username=name
            )
            record_op(
                s,
                "credentials.query_api.generate",
                f"id={cred.id} owner={uid} via=users.create",
            )
            set_flash_viewer_token(
                request,
                username=name,
                token=plain,
                key_hint=cred.key_hint,
                user_id=uid,
            )
    invalidate_users_exist_cache()
    # 首个用户：自动登录，避免创建后立刻被踢到 /login
    if n == 0:
        import time

        from radar.server.routes.auth_routes import SESSION_IAT, SESSION_UID, SESSION_VER

        request.session[SESSION_UID] = uid
        request.session[SESSION_VER] = 0
        request.session[SESSION_IAT] = int(time.time())
    return RedirectResponse("/settings?tab=users", status_code=303)


@router.post("/settings/users/{user_id}/role")
def set_user_role(user_id: int, role: str = Form(...)):
    from sqlalchemy import func

    from radar.auth.rbac import ROLE_ADMIN, ROLE_VIEWER, VALID_ROLES
    from radar.server.query_api_auth import KIND, provision_viewer_query_token
    from radar.storage.models import AppUser, Credential
    from radar.sys_log import record_op

    role_v = (role or "").strip().lower()
    if role_v not in VALID_ROLES:
        return RedirectResponse("/settings?tab=users&err=role", status_code=303)
    with get_session() as s:
        u = s.get(AppUser, user_id)
        if u is None:
            return RedirectResponse("/settings?tab=users", status_code=303)
        if u.role == ROLE_ADMIN and role_v != ROLE_ADMIN and _admin_count(s) <= 1:
            return RedirectResponse("/settings?tab=users&err=last_admin", status_code=303)
        prev = u.role
        u.role = role_v
        record_op(s, "users.role", f"{u.username} → {role_v}")
        # 降为普通用户且尚无专属 Token → 补发（明文不回显，可在查询 API 页再生成）
        if prev != ROLE_VIEWER and role_v == ROLE_VIEWER:
            n_own = (
                s.execute(
                    select(func.count())
                    .select_from(Credential)
                    .where(
                        Credential.kind == KIND,
                        Credential.owner_user_id == u.id,
                    )
                ).scalar()
                or 0
            )
            if n_own == 0:
                _, cred = provision_viewer_query_token(
                    s, user_id=int(u.id), username=u.username
                )
                record_op(
                    s,
                    "credentials.query_api.generate",
                    f"id={cred.id} owner={u.id} via=users.role",
                )
    return RedirectResponse("/settings?tab=users", status_code=303)


@router.post("/settings/users/{user_id}/password")
def reset_user_password(user_id: int, password: str = Form(...)):
    from radar.auth.passwords import hash_password
    from radar.storage.models import AppUser
    from radar.sys_log import record_op

    try:
        pw_hash = hash_password(password)
    except ValueError:
        return RedirectResponse("/settings?tab=users&err=password", status_code=303)
    with get_session() as s:
        u = s.get(AppUser, user_id)
        if u is None:
            return RedirectResponse("/settings?tab=users", status_code=303)
        u.password_hash = pw_hash
        # 改密后旧会话 token 立即过期
        u.session_ver = int(u.session_ver or 0) + 1
        record_op(s, "users.password", f"{u.username}")
    return RedirectResponse("/settings?tab=users", status_code=303)


@router.post("/settings/users/{user_id}/toggle")
def toggle_user(request: Request, user_id: int):
    from radar.auth.rbac import ROLE_ADMIN
    from radar.storage.models import AppUser
    from radar.sys_log import record_op

    me = getattr(request.state, "user", None)
    with get_session() as s:
        u = s.get(AppUser, user_id)
        if u is None:
            return RedirectResponse("/settings?tab=users", status_code=303)
        if me is not None and me.id == u.id:
            return RedirectResponse("/settings?tab=users&err=self", status_code=303)
        # 禁用最后一个 admin → 拒
        if u.enabled and u.role == ROLE_ADMIN and _admin_count(s) <= 1:
            return RedirectResponse("/settings?tab=users&err=last_admin", status_code=303)
        u.enabled = not u.enabled
        record_op(s, "users.toggle", f"{u.username} enabled={u.enabled}")
    return RedirectResponse("/settings?tab=users", status_code=303)


@router.post("/settings/users/{user_id}/delete")
def delete_user(request: Request, user_id: int):
    from radar.auth.rbac import ROLE_ADMIN, invalidate_users_exist_cache
    from radar.storage.models import AppUser
    from radar.sys_log import record_op

    me = getattr(request.state, "user", None)
    with get_session() as s:
        u = s.get(AppUser, user_id)
        if u is None:
            return RedirectResponse("/settings?tab=users", status_code=303)
        if me is not None and me.id == u.id:
            return RedirectResponse("/settings?tab=users&err=self", status_code=303)
        if u.role == ROLE_ADMIN and u.enabled and _admin_count(s) <= 1:
            return RedirectResponse("/settings?tab=users&err=last_admin", status_code=303)
        name = u.username
        s.delete(u)
        record_op(s, "users.delete", name)
    invalidate_users_exist_cache()
    return RedirectResponse("/settings?tab=users", status_code=303)
