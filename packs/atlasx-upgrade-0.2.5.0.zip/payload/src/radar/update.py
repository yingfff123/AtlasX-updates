"""版本检查与升级包应用。

升级包（.zip）：
  manifest.json  → {name, version, notes?, sha256?}
  payload/       → 可覆盖到项目根的相对路径文件（仅白名单前缀）

更新通道：
  1) RADAR_UPDATE_CHANNEL_URL → JSON {version, notes?, download_url, sha256?}
  2) 默认 GitHub Releases API（AtlasX/AtlasX）
"""

from __future__ import annotations

import hashlib
import io
import json
import platform
import re
import shutil
import subprocess
import tempfile
import threading
import time
import zipfile
from dataclasses import dataclass, replace
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import httpx

from radar import __version__ as CURRENT_VERSION

REPO_ROOT = Path(__file__).resolve().parents[2]
UPDATES_DIR = REPO_ROOT / "var" / "updates"
DEFAULT_GITHUB_REPO = "AtlasX/AtlasX"

# 升级包只允许覆盖这些相对路径前缀 / 文件
_ALLOWED_PREFIXES = (
    "src/",
    "migrations/",
    "scripts/",
    "tools/",
    "data/",
    "var/atlasx/engine/",
    "var/engine/",
)
_ALLOWED_FILES = frozenset(
    {
        "pyproject.toml",
        "uv.lock",
        "Makefile",
        "alembic.ini",
        "README.md",
        ".env.example",
    }
)

_VERSION_RE = re.compile(
    r"v?(?P<major>\d+)\.(?P<minor>\d+)\.(?P<patch>\d+)"
    r"(?:\.(?P<build>\d+))?(?P<pre>[a-zA-Z][a-zA-Z0-9.\-]*)?"
)


@dataclass(frozen=True)
class VersionInfo:
    current: str
    latest: str | None
    is_latest: bool
    update_available: bool
    notes: str
    download_url: str
    sha256: str
    channel: str
    error: str = ""


def parse_version(raw: str) -> tuple[int, int, int, int, str]:
    """接受 0.2.5 / 0.2.5.0 / v0.2.5 / upgrade-0.2.5.0。

    第四段 build：缺失为 -1，故 0.2.5.0 > 0.2.5。
    """
    s = (raw or "").strip()
    m = _VERSION_RE.search(s)
    if not m:
        raise ValueError(f"非法版本号: {raw!r}")
    build_raw = m.group("build")
    return (
        int(m.group("major")),
        int(m.group("minor")),
        int(m.group("patch")),
        int(build_raw) if build_raw is not None else -1,
        m.group("pre") or "",
    )


def canonical_version(raw: str) -> str:
    major, minor, patch, build, pre = parse_version(raw)
    base = f"{major}.{minor}.{patch}"
    if build >= 0:
        base = f"{base}.{build}"
    return f"{base}{pre}"


def normalize_sha256(raw: str) -> str:
    """接受 64 hex 或 `sha256:<hex>`；非法则空串。"""
    s = (raw or "").strip().lower()
    if s.startswith("sha256:"):
        s = s.split(":", 1)[1].strip()
    if len(s) == 64 and all(c in "0123456789abcdef" for c in s):
        return s
    return ""


def resolve_pack_digest(raw: bytes, declared: str = "") -> str:
    """应用本地/上传包：缺或非法声明时用文件自身 sha256；声明合法则必须一致。"""
    digest = hashlib.sha256(raw).hexdigest()
    expected = normalize_sha256(declared)
    if expected and expected != digest:
        raise ValueError("升级包 sha256 校验失败")
    return digest


def last_applied_digest() -> str:
    """最近一次成功应用的升级包 sha256；没有则空串。"""
    try:
        if not UPDATES_DIR.is_dir():
            return ""
        files = [p for p in UPDATES_DIR.glob("applied-*.zip") if p.is_file()]
        if not files:
            return ""
        newest = max(files, key=lambda p: p.stat().st_mtime)
        return hashlib.sha256(newest.read_bytes()).hexdigest()
    except OSError:
        return ""


def compare_versions(a: str, b: str) -> int:
    """返回 -1 / 0 / 1。四段 build 后比预发布后缀；预发布低于同号正式版。"""
    aa, bb = parse_version(a), parse_version(b)
    for x, y in zip(aa[:4], bb[:4], strict=True):
        if x != y:
            return -1 if x < y else 1
    if aa[4] == bb[4]:
        return 0
    if not aa[4]:
        return 1
    if not bb[4]:
        return -1
    return -1 if aa[4] < bb[4] else 1


def current_version() -> str:
    return CURRENT_VERSION


def schedule_service_restart(*, delay_sec: float = 1.5) -> None:
    """升级写盘后延迟重启本实例（macOS LaunchAgent / 否则 daemon.sh）。

    先返回 HTTP 再重启，避免客户端收不到成功响应。
    """

    def _run() -> None:
        time.sleep(max(0.0, float(delay_sec)))
        root = REPO_ROOT
        launch = root / "scripts" / "install-launchagent.sh"
        daemon = root / "scripts" / "daemon.sh"
        try:
            if platform.system() == "Darwin" and launch.is_file():
                subprocess.run(
                    ["bash", str(launch), "install"],
                    cwd=str(root),
                    check=False,
                    timeout=120,
                )
            elif daemon.is_file():
                subprocess.run(
                    ["bash", str(daemon), "restart"],
                    cwd=str(root),
                    check=False,
                    timeout=120,
                )
        except Exception:  # noqa: BLE001
            pass

    threading.Thread(target=_run, name="atlasx-upgrade-restart", daemon=True).start()


def _channel_url() -> str:
    from radar.config import settings

    return (getattr(settings, "update_channel_url", None) or "").strip()


def _github_repo() -> str:
    from radar.config import settings

    return (getattr(settings, "update_github_repo", None) or DEFAULT_GITHUB_REPO).strip()


def _cache_bust(url: str) -> str:
    """jsDelivr 默认缓存 7 天；检查时按小时打戳，避免通道更新后仍读旧 sha256。"""
    if "jsdelivr.net" not in (url or ""):
        return url
    stamp = datetime.now(UTC).strftime("%Y%m%d%H")
    sep = "&" if "?" in url else "?"
    return f"{url}{sep}t={stamp}"


def _with_hotfix(info: VersionInfo) -> VersionInfo:
    """同版本但通道 sha256 ≠ 上次已应用 → 仍算有补丁。"""
    if info.error or not info.latest or info.update_available:
        return info
    sha = (info.sha256 or "").strip().lower()
    if len(sha) != 64:
        return info
    try:
        if compare_versions(info.current, info.latest) != 0:
            return info
    except ValueError:
        return info
    applied = last_applied_digest()
    if applied and applied == sha:
        return info
    return replace(info, update_available=True, is_latest=False)


def check_latest(*, timeout: float = 15.0, client: httpx.Client | None = None) -> VersionInfo:
    """检查远程是否有更新。测试可注入 httpx.Client（含 MockTransport）。

    通道 JSON 与 GitHub Releases 都拉；资产 sha256 / 下载地址以 GitHub 为准
    （jsDelivr @main 会脏缓存）。GitHub 不可达时退回通道。
    """
    cur = current_version()
    own = client is None
    if own:
        client = httpx.Client(timeout=timeout, follow_redirects=True)
    assert client is not None
    errors: list[str] = []
    try:
        channel = _channel_url()
        channel_info: VersionInfo | None = None
        github_info: VersionInfo | None = None
        if channel:
            try:
                channel_info = _from_manifest_url(client, _cache_bust(channel), cur)
            except Exception as exc:  # noqa: BLE001
                errors.append(str(exc)[:160])
        try:
            github_info = _from_github(client, _github_repo(), cur)
        except Exception as exc:  # noqa: BLE001
            errors.append(str(exc)[:160])
        merged = _merge_channel_and_github(channel_info, github_info)
        if merged is not None:
            return _with_hotfix(merged)
        return VersionInfo(
            current=cur,
            latest=None,
            is_latest=True,
            update_available=False,
            notes="",
            download_url="",
            sha256="",
            channel=channel or f"github:{_github_repo()}",
            error="; ".join(errors)[:200],
        )
    finally:
        if own:
            client.close()


def _merge_channel_and_github(
    channel: VersionInfo | None, github: VersionInfo | None
) -> VersionInfo | None:
    """jsDelivr @main 常缓存旧 sha256；仅当 GitHub 资产带 digest 时覆盖。"""
    if channel is None:
        return github
    if github is None or not github.sha256:
        return channel
    sha = github.sha256
    url = github.download_url or channel.download_url
    notes = (channel.notes or github.notes or "")[:2000]
    latest = github.latest or channel.latest
    if not latest:
        return replace(channel, sha256=sha, download_url=url, notes=notes)
    cmp = compare_versions(channel.current, latest)
    return replace(
        channel,
        latest=latest,
        notes=notes,
        download_url=url,
        sha256=sha,
        is_latest=cmp >= 0,
        update_available=cmp < 0,
    )


def _from_manifest_url(client: httpx.Client, url: str, cur: str) -> VersionInfo:
    r = client.get(url)
    r.raise_for_status()
    data = r.json()
    latest = canonical_version(str(data.get("version") or "").strip())
    cmp = compare_versions(cur, latest)
    return VersionInfo(
        current=cur,
        latest=latest,
        is_latest=cmp >= 0,
        update_available=cmp < 0,
        notes=str(data.get("notes") or data.get("body") or "")[:2000],
        download_url=str(data.get("download_url") or data.get("url") or "").strip(),
        sha256=normalize_sha256(str(data.get("sha256") or "")),
        channel=url.split("?", 1)[0],
    )


def _from_github(client: httpx.Client, repo: str, cur: str) -> VersionInfo:
    api = f"https://api.github.com/repos/{repo}/releases/latest"
    r = client.get(
        api,
        headers={"Accept": "application/vnd.github+json"},
        timeout=5.0,
    )
    if r.status_code == 404:
        return VersionInfo(
            current=cur,
            latest=cur,
            is_latest=True,
            update_available=False,
            notes="远程尚无正式 release",
            download_url="",
            sha256="",
            channel=f"github:{repo}",
        )
    r.raise_for_status()
    data = r.json()
    latest = canonical_version(str(data.get("tag_name") or data.get("name") or "").strip())
    download = ""
    sha256 = ""
    assets = data.get("assets") or []

    def _asset_sha(a: dict) -> str:
        return normalize_sha256(str(a.get("digest") or a.get("sha256") or ""))

    picked: dict | None = None
    for a in assets:
        name = str(a.get("name") or "").lower()
        if name.endswith(".zip") and (
            "upgrade" in name
            or "update" in name
            or "atlasx" in name
            or "atlas-x" in name
            or "asmradar" in name
        ):
            picked = a
            break
    if picked is None:
        for a in assets:
            if str(a.get("name") or "").lower().endswith(".zip"):
                picked = a
                break
    if picked is not None:
        download = str(picked.get("browser_download_url") or "")
        sha256 = _asset_sha(picked)
    if not download:
        download = str(data.get("zipball_url") or "").strip()
    cmp = compare_versions(cur, latest)
    return VersionInfo(
        current=cur,
        latest=latest,
        is_latest=cmp >= 0,
        update_available=cmp < 0,
        notes=str(data.get("body") or "")[:2000],
        download_url=download,
        sha256=sha256,
        channel=f"github:{repo}",
    )


def download_upgrade_pack(
    url: str,
    *,
    expected_sha256: str = "",
    timeout: float = 120.0,
    client: httpx.Client | None = None,
    max_redirects: int = 5,
) -> Path:
    """下载升级包到 var/updates/，返回本地路径。

    强制：公网 http(s)（防 SSRF）+ 非空 sha256（防篡改包）。
    不自动跟随重定向：逐跳重新做 SSRF 校验，防止 302 进内网。
    """
    from urllib.parse import urljoin

    from radar.core.net import is_safe_public_url

    url = (url or "").strip()
    if not url.startswith(("http://", "https://")):
        raise ValueError("下载地址必须是 http(s) URL")
    expected = normalize_sha256(expected_sha256)
    if not expected:
        raise ValueError("必须提供有效的 sha256（64 位十六进制）方可下载升级包")
    UPDATES_DIR.mkdir(parents=True, exist_ok=True)
    own = client is None
    if own:
        # 禁止自动跟随：每跳手工校验 Location
        client = httpx.Client(timeout=timeout, follow_redirects=False)
    assert client is not None
    try:
        current = url
        for _ in range(max(1, int(max_redirects)) + 1):
            if not is_safe_public_url(current):
                raise ValueError("下载地址非法（仅允许公网 http/https，已拒绝 SSRF 目标）")
            with client.stream("GET", current) as r:
                if r.status_code in (301, 302, 303, 307, 308):
                    loc = (r.headers.get("location") or "").strip()
                    if not loc:
                        raise ValueError("重定向缺少 Location")
                    current = urljoin(current, loc)
                    continue
                r.raise_for_status()
                name = current.rstrip("/").split("/")[-1] or "upgrade-pack.zip"
                if "?" in name:
                    name = name.split("?", 1)[0]
                if not name.lower().endswith(".zip"):
                    name = f"{name}.zip"
                dest = UPDATES_DIR / name
                h = hashlib.sha256()
                with dest.open("wb") as f:
                    for chunk in r.iter_bytes():
                        f.write(chunk)
                        h.update(chunk)
                digest = h.hexdigest()
                if digest.lower() != expected:
                    dest.unlink(missing_ok=True)
                    raise ValueError("升级包 sha256 校验失败")
                return dest
        raise ValueError("重定向次数过多")
    finally:
        if own:
            client.close()


def require_pack_sha256(raw: bytes, expected_sha256: str) -> str:
    """校验升级包字节与声明 sha256 一致，返回规范化 digest。"""
    expected = normalize_sha256(expected_sha256)
    if not expected:
        raise ValueError("必须提供有效的 sha256（64 位十六进制）方可应用升级包")
    digest = hashlib.sha256(raw).hexdigest()
    if digest != expected:
        raise ValueError("升级包 sha256 校验失败")
    return digest


def _read_manifest(zf: zipfile.ZipFile) -> dict[str, Any]:
    names = zf.namelist()
    for candidate in ("manifest.json", "upgrade-manifest.json"):
        if candidate in names:
            return json.loads(zf.read(candidate).decode("utf-8"))
        for n in names:
            if n.endswith("/" + candidate) and n.count("/") == 1:
                return json.loads(zf.read(n).decode("utf-8"))
    raise ValueError("升级包缺少 manifest.json")


def _payload_members(zf: zipfile.ZipFile) -> list[tuple[str, str]]:
    """返回 (zip内路径, 相对项目根路径) 列表。"""
    out: list[tuple[str, str]] = []
    for name in zf.namelist():
        if name.endswith("/"):
            continue
        norm = name.replace("\\", "/")
        if norm.startswith("/") or ".." in norm.split("/"):
            raise ValueError(f"升级包含非法路径: {name}")
        rel = norm
        parts = rel.split("/")
        names = zf.namelist()
        if (
            parts
            and parts[0] not in ("payload", "manifest.json", "upgrade-manifest.json")
            and len(parts) > 1
            and (
                any(n.startswith(parts[0] + "/payload/") for n in names)
                or any(n == f"{parts[0]}/manifest.json" for n in names)
            )
        ):
            rel = "/".join(parts[1:])
        if rel in ("manifest.json", "upgrade-manifest.json"):
            continue
        rel = rel.removeprefix("payload/")
        if not rel:
            continue
        if rel in _ALLOWED_FILES or any(rel.startswith(p) for p in _ALLOWED_PREFIXES):
            out.append((name, rel))
    return out


def inspect_upgrade_pack(path: Path | bytes) -> dict[str, Any]:
    """解析升级包，返回 {version, notes, files, sha256, force_upgrade?}。"""
    raw = path if isinstance(path, (bytes, bytearray)) else Path(path).read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    with zipfile.ZipFile(io.BytesIO(raw)) as zf:
        meta = _read_manifest(zf)
        members = _payload_members(zf)
    version = str(meta.get("version") or "").strip()
    if not version:
        raise ValueError("manifest 缺少 version")
    parse_version(version)
    name = str(meta.get("name") or "AtlasX").strip()
    force = meta.get("force_upgrade") in (True, 1, "1", "true", "True", "yes", "on")
    return {
        "name": name or "AtlasX",
        "version": version.lstrip("vV"),
        "notes": str(meta.get("notes") or "")[:2000],
        "files": [rel for _, rel in members],
        "file_count": len(members),
        "sha256": digest,
        "manifest_sha256": str(meta.get("sha256") or "").strip().lower(),
        "force_upgrade": bool(force),
    }


def apply_upgrade_pack(
    path: Path | bytes,
    *,
    allow_downgrade: bool = False,
    allow_same: bool = False,
    dry_run: bool = False,
) -> dict[str, Any]:
    """应用升级包：覆盖白名单文件。需重启服务后生效。

    同版本默认拒绝；manifest.force_upgrade=true 或 allow_same=True（用户点应用）时允许覆盖。
    """
    raw = path if isinstance(path, (bytes, bytearray)) else Path(path).read_bytes()
    info = inspect_upgrade_pack(raw)
    cmp = compare_versions(current_version(), info["version"])
    if cmp > 0 and not allow_downgrade:
        raise ValueError(f"拒绝降级：当前 {current_version()} > 包内 {info['version']}")
    if cmp == 0 and not allow_downgrade and not info.get("force_upgrade") and not allow_same:
        raise ValueError(f"已是该版本：{info['version']}")

    with zipfile.ZipFile(io.BytesIO(raw)) as zf:
        members = _payload_members(zf)
        if not members:
            raise ValueError("升级包 payload 为空或无可覆盖文件")
        written: list[str] = []
        if dry_run:
            return {
                **info,
                "written": [rel for _, rel in members],
                "dry_run": True,
                "restart_required": False,
            }
        with tempfile.TemporaryDirectory(prefix="radar-upgrade-") as tmp:
            tmp_path = Path(tmp)
            for zip_name, rel in members:
                target = (REPO_ROOT / rel).resolve()
                if not str(target).startswith(str(REPO_ROOT.resolve())):
                    raise ValueError(f"路径逃逸: {rel}")
                target.parent.mkdir(parents=True, exist_ok=True)
                data = zf.read(zip_name)
                staging = tmp_path / rel
                staging.parent.mkdir(parents=True, exist_ok=True)
                staging.write_bytes(data)
                shutil.copy2(staging, target)
                written.append(rel)

    UPDATES_DIR.mkdir(parents=True, exist_ok=True)
    bak = UPDATES_DIR / f"applied-{info['version']}-{info['sha256'][:12]}.zip"
    if not isinstance(path, (bytes, bytearray)):
        if Path(path).resolve() != bak.resolve():
            shutil.copy2(path, bak)
    else:
        bak.write_bytes(raw)

    return {
        **info,
        "written": written,
        "dry_run": False,
        "restart_required": True,
        "backup": str(bak),
    }


def build_upgrade_pack_bytes(
    *,
    version: str,
    files: dict[str, bytes],
    notes: str = "",
    force_upgrade: bool = False,
) -> bytes:
    """测试/打包辅助：构造最小升级包。"""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        manifest = {"name": "AtlasX", "version": version, "notes": notes}
        if force_upgrade:
            manifest["force_upgrade"] = True
        zf.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2))
        for rel, data in files.items():
            zf.writestr(f"payload/{rel}", data)
    return buf.getvalue()
