"""应用配置：恰好两项 env，其余 secrets 走设置页 Fernet 加密入库。"""

from __future__ import annotations

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_prefix="RADAR_", extra="ignore")

    database_url: str = "postgresql+psycopg://postgres:radar@localhost:5432/atlasx_clean"
    master_key: str = ""  # Fernet 主密钥，唯一非空硬门槛
    access_token: str = ""  # 可选 Web 访问 token（仅 Bearer；空 = 本机开放）
    finding_cap: int = 50_000  # 单 run 截断
    wildcard_thresholds: dict = {"k": 5, "hits": 2, "multi_ips": 2}  # 采样数/命中数/CDN 多解析阈值
    # LLM（Agent 层；非硬依赖：none = 全规则降级，系统完整可用）
    llm_provider: str = "none"  # none|deepseek|dashscope|zhipu|minimax|ollama
    llm_api_key: str = ""  # 用户自带；永不出现在代码/日志
    llm_base_url: str = ""  # 覆盖预置 base_url（openai_compat 自定义端点用）
    llm_model_small: str = ""  # 覆盖预置小模型档位
    llm_model_large: str = ""  # 覆盖预置大模型档位（JS 分析/图推理）
    llm_daily_token_budget: int = 2_000_000  # 全局日 token 上限，耗尽即降级
    llm_request_interval_ms: int = 500  # 请求最小间隔（ms），防 429
    # crawlora_bing 深度扫描预算（付费源，3 credits/次）：单域总查询数上限（含子域标签扫描）。
    # 免费层 2000 credits/月 ≈ 666 次/月，30 次/域约 11 个域/月，需自行权衡。
    crawlora_bing_max_queries: int = 30
    crawlora_bing_label_sweep: bool = True  # 是否做常见子域标签扫描（inurl:label.root）
    # crawlora_google：site: 域限定（Bing 做不到）；与 bing 共用 key；默认 12 次/域
    crawlora_google_max_queries: int = 12
    # github_dork 深度预算：Code Search 硬限 10 次/分钟，默认 35 dork ≈ 3.5 分钟/域；
    # 按 category 加权轮询（secret×3 / config×2 / 其余×1），高信号优先；
    # 深扫可调大（_DORKS 全量 ≈ 5+ 分钟/域）。0/None → 至少 1。
    # 环境变量：RADAR_GITHUB_DORK_QUERIES
    github_dork_queries: int = 35
    # github 加深档：filter=只分类；standard=归因 + 确认后 org:/user: 定向搜
    # 环境变量：RADAR_GITHUB_DEPTH
    github_depth: str = "standard"
    # 主动探测总开关：关掉后，SOURCE_TYPE=='active' 的采集器（如 ksubdomain DNS爆破）
    # 不执行；被动源 + 所有 enricher HTTP 探测照常。SRC 情报收集可关，纯审计场景保留。
    active_probing: bool = True
    # scan worker：多任务并发上限 + 心跳/中断再入队（见 scan-worker design）
    scan_concurrency: int = 3
    scan_heartbeat_sec: int = 30
    scan_interrupt_timeout_sec: int = 120
    scan_requeue_max: int = 3
    # 系统更新：自定义通道 JSON（version/download_url/sha256）；空则走 GitHub Releases
    # 勿默认 jsDelivr @main：CDN 会脏缓存旧 sha256，导致「下载校验失败」。
    update_channel_url: str = ""
    update_github_repo: str = "yingfff123/AtlasX-updates"
    # Pro 授权通道（仅服务端；空 = 用 activate.py 内置混淆默认）
    license_server: str = ""
    license_api_key: str = ""
    license_grace_days: int = 7
    license_cache_sec: float = 60.0


settings = Settings()
